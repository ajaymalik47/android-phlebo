package com.diagright.imageloader

import android.content.Context
import android.graphics.Bitmap
import android.widget.ImageView
import androidx.annotation.DrawableRes

interface ImageLoader {
    fun load(imageView: ImageView, url: String)
    fun load(imageView: ImageView, url: String, @DrawableRes placeHolder: Int)
    fun load(imageView: ImageView, @DrawableRes drawableId: Int)
    fun load(imageView: ImageView, @DrawableRes drawableId: Int, @DrawableRes placeHolder: Int)
    fun downloadAsBitmap(context: Context, imageUrl: String, callback: (bitmap: Bitmap?) -> Unit)
}