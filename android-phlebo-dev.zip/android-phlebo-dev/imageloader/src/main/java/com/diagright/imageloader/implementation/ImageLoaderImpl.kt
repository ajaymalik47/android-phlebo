package com.diagright.imageloader.implementation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.diagright.imageloader.ImageLoader

class ImageLoaderImpl : ImageLoader {

    override fun load(imageView: ImageView, url: String) {
        Glide.with(imageView).load(url).into(imageView)
    }

    override fun load(imageView: ImageView, url: String, placeHolder: Int) {
        Glide.with(imageView).load(url).placeholder(placeHolder).into(imageView)
    }

    override fun load(imageView: ImageView, drawableId: Int) {
        Glide.with(imageView).load(drawableId).into(imageView)
    }

    override fun load(imageView: ImageView, drawableId: Int, placeHolder: Int) {
        Glide.with(imageView).load(drawableId).placeholder(drawableId).into(imageView)
    }

    override fun downloadAsBitmap(context: Context, imageUrl: String, callback: (bitmap: Bitmap?) -> Unit) {
        Glide.with(context)
            .asBitmap()
            .load(imageUrl)
            .into(object : CustomTarget<Bitmap>(){
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    callback(resource)
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    callback(null)
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

}