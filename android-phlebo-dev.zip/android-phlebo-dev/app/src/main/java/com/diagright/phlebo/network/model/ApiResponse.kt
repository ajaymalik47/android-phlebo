package com.diagright.phlebo.network.model

import androidx.annotation.Keep

@Keep
data class ApiResponse<T>(
    var data: T?,
    var status: ApiStatus?
)