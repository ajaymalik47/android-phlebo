package com.diagright.phlebo.network.exceptions;

public class ServerErrorExceptionCustom extends CustomHttpException
{
    public ServerErrorExceptionCustom(String message)
    {
        super(message);
    }
}
