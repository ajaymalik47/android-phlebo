package com.diagright.phlebo.network

import okhttp3.RequestBody
import retrofit2.Converter

/**
 * @author Vinayak
 */
class ApiRequestBodyConverter<T>(private val converter: Converter<T, RequestBody>): Converter<T, RequestBody>  {

    override fun convert(value: T): RequestBody? {
        return converter.convert(value)
    }
}