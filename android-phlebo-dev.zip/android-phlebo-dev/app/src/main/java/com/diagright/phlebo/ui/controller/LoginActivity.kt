package com.diagright.phlebo.ui.controller

import ExceptionHandler
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.ActivityLoginBinding
import com.diagright.phlebo.di.LoginActivityFactory
import com.diagright.phlebo.ui.states.LoginActivityStates
import com.diagright.phlebo.ui.viewmodel.LoginViewModel
import com.diagright.phlebo.utility.UtilityClass
import com.diagright.phlebo.utility.toast.ToastHandler

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        init()
    }

    private fun init() {
        setToolbar()
        setViewModel()
        observeData()
    }

    private fun setToolbar() {
        binding.loginToolbar.title = Constants.EMPTY
        setSupportActionBar(binding.loginToolbar)
        binding.loginToolbar.setNavigationOnClickListener { onBackPressed() }
        supportActionBar?.run {
            setDisplayShowTitleEnabled(true)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setViewModel() {
        val loginFactory = LoginActivityFactory()
        viewModel = ViewModelProvider(this, loginFactory).get(LoginViewModel::class.java)
        binding.loginViewModel = viewModel
    }

    private fun observeData() {
        viewModel.getLoginStates().observe(this, Observer {
            when (it) {
                is LoginActivityStates.ShowProgress -> {
                    showProgress()
                }

                is LoginActivityStates.OtpVerified -> {
                    HomeActivity.startActivity(this)
                    exitActivity()
                }

                is LoginActivityStates.ShowError -> {
                    hideProgress()
                    ExceptionHandler.handle(it.exception, this)
                }

                is LoginActivityStates.InvalidMobile -> {
                    binding.emailPhone.error = getString(R.string.invalid_mobile_number)
                    hideProgress()
                }

                is LoginActivityStates.InvalidOtp -> binding.otpField.error =
                    getString(R.string.invalid_mobile_number)

                is LoginActivityStates.OtpSent -> {
                    binding.otpField.visibility = View.VISIBLE
                    binding.resendOtp.visibility = View.VISIBLE
                    hideProgress()
                    binding.button.text = getString(R.string.verify_otp)
                }

                is LoginActivityStates.MaxRetryReached -> {
                    showToast(getString(R.string.max_retry_reached))
                }

                is LoginActivityStates.StartTimer -> {
                    showProgress()
                    startTimer()
                }
            }
        })
    }

    private fun startTimer() {
        val timer = object : CountDownTimer(
            Constants.TIMER_FOR_OTP, Constants.SECONDS_IN_MILLIS
        ) {
            override fun onTick(millisUntilFinished: Long) {
                val timeLeft = millisUntilFinished / 1000
                binding.resendOtp.text = "Resend OTP: $timeLeft"
            }

            override fun onFinish() {
                binding.resendOtp.text = "Resend OTP"
            }
        }
        timer.start()
    }

    private fun showProgress() {
        binding.progress.visibility = View.VISIBLE
    }

    private fun hideProgress() {
        binding.progress.visibility = View.GONE
    }

    private fun showToast(message: String) {
        ToastHandler.INSTANCE.showToast(this, message, Toast.LENGTH_SHORT)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        exitActivity()
    }

    private fun exitActivity() {
        UtilityClass.overrideEnterTransition(this)
        finish()
    }
}
