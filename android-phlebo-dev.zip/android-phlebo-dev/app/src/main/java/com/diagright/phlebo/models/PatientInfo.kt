package com.diagright.phlebo.models

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.android.parcel.Parcelize

/**
 * @author by Vinayak Gupta
 */
@Parcelize
@Keep
data class PatientInfo(
    val age: Int,
    val name: String?,
    val gender: String?,
    val salutation: String?,
    val relation: String?,
    val patientId: String,
    var barcode: String?
) : Parcelable