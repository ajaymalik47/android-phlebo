package com.diagright.phlebo.network.exceptions;

public class ApiStatusExceptionCustom extends CustomHttpException
{
    public ApiStatusExceptionCustom(String message)
    {
        super(message);
    }

    public ApiStatusExceptionCustom(String message, int code)
    {
        super(message, code);
    }

    public ApiStatusExceptionCustom(int responseCode, String message, int code)
    {
        super(responseCode, message, code);
    }
}
