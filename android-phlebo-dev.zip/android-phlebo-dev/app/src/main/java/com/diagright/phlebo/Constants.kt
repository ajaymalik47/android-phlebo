package com.diagright.phlebo

//import com.diagright.phlebo.config.ConfigBuilder

/**
 * @author by Vinayak Gupta
 */
object Constants {

//    val RETROFIT_BASE_URL: String = ConfigBuilder.getConfig().hostUrl
    val RETROFIT_BASE_URL: String = "https://stagapi.diagright.com/"

    // errors
    const val UNAUTHORIZED_ACCESS = "Unauthorized access. Please sign in again."
    const val MESSAGE_RESOURCE_NOT_FOUND = "Requested resource does not exist. Please try again."
    const val MESSAGE_SERVER_ERROR = "Our servers are under maintenance. We would be back shortly."
    const val REQUEST_TIMED_OUT = "Request timed out. Please try again later."
    const val COULDNT_REACH_OUR_SERVERS = "Couldn't reach our servers. Please try again later."
    const val BAD_REQUEST = "Bad request. Try again later"
    const val JSON_PARSER_EXCEPTION = "Unable to parse json."
    const val NO_DATA_RECEIVED = "No data received"
    const val SOME_ERROR_OCCURRED = "some error occurred"

    const val DIGIT_6: Char = '6'
    const val DIGIT_7: Char = '7'
    const val DIGIT_8: Char = '8'
    const val DIGIT_9: Char = '9'
    const val UTF8 = "UTF-8"
    const val AMP = "amp"
    const val PLAIN_TEXT = "text/plain"
    const val TYPE_PDF = "application/pdf"
    const val MAP_NAVIGATION_URL = "google.navigation:q=%s, %s"
    const val URI_TELEPHONE = "tel:%S"
    const val UNABLE_TO_SCAN = "Unable to scan! Enter manually"
    const val INTENT_ORDER_DATA = "intent_order_data"
    const val INTENT_SCANNED_RESULT = "intent_scanned_result"
    const val ORDER_STATE = "orderState"
    const val ORDER_ID = "orderId"
    const val OK = "Ok"
    const val CANCEL = "Cancel"
    const val EMAIL = "Email: %s"
    const val MOBILE = "Phone: %s"
    const val MUST_IMPLEMENT = "Must Implement"
    const val PAYMENT_MODE_COD = "COD"
    const val LEGAL_WEB_URL = "https://www.diagright.com/legal"
    const val INTENT_WEBVIEW_URL = "intent_webview_url"
    const val FCM_TOKEN = "fcmToken"

    const val SECONDS_IN_MILLIS: Long = 1000
    const val MIN_MOBILE_LENGTH = 10
    const val OTP_LENGTH = 6
    const val CUSTOMER_CARE_NUMBER: Long = 9504259504
    const val BITMAP_LEVEL_LOW = 1
    const val BITMAP_LEVEL_HIGH = 1
    const val MAX_OTP_RETRY = 3
    const val TIMER_FOR_OTP: Long = (30 * SECONDS_IN_MILLIS).toLong()

    //Req-Codes
    const val REQ_CODE_ACTION_AUTHENTICATION = 1002
    const val REQ_CODE_ORDER_DETAILS = 1005

    // Delimeters
    const val EMPTY = ""
    const val CHAR_EMPTY = ' '
    const val UNDERSCORE = "_"
    const val HYPHEN = "-"
    const val COMMA_WITH_WHITESPACE = ", "
    const val AMPERSAND = "&"
    const val EQUAL = "="
    const val WHITESPACE = " "
    const val QUESTION_MARK = "?"
    const val BULLET = "\u2022"

    object OrderStates {
        const val CANCELLED = "CANCELLED"
        const val RESCHEDULE = "RESCHEDULED"
        const val SAMPLE_COLLECTED = "SAMPLE COLLECTED"
        const val SAMPLE_IN_LAB = "SAMPLE IN LAB"
        const val PHLEBO_ASSIGNED = "PHLEBO ASSIGNED"
        const val SCHEDULED = "SCHEDULED"
    }

    object Headers {
        const val CONTENT_TYPE_KEY = "Content-Type"
        const val CONTENT_TYPE_VALUE = "application/json"
        const val AUTHORIZATION_KEY = "Authorization"
    }

    object BuildConstants {
        const val PROD = "prod"
        const val DEBUG = "debug"
        const val DEV = "dev"
    }
}