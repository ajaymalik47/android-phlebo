package com.diagright.phlebo.ui.viewmodel

import androidx.databinding.ObservableField
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.diagright.phlebo.Constants
import com.diagright.phlebo.Coroutines
import com.diagright.phlebo.singletons.LoginSingleton
import com.diagright.phlebo.ui.domain.LoginActivityRepository
import com.diagright.phlebo.ui.states.LoginActivityStates

/**
 * @author by Vinayak Gupta
 */
class LoginViewModel(private val loginActivityRepository: LoginActivityRepository) :
    ViewModel() {

    private val loginMutableStates = MutableLiveData<LoginActivityStates>()
    private val loginLiveStates: LiveData<LoginActivityStates> get() = loginMutableStates

    val mobileField = ObservableField(Constants.EMPTY)
    val otpField = ObservableField(Constants.EMPTY)
    private var mobile: String = Constants.EMPTY
    private var otp: String = Constants.EMPTY

    fun onSendOtpClicked() {
        mobile = mobileField.get().toString()
        otp = otpField.get().toString()
        if (!LoginSingleton.isOtpSent) {
            if (isMobileValid(mobile)) {
                loginMutableStates.postValue(LoginActivityStates.ShowProgress)
                sendOtp()
            } else {
                loginMutableStates.postValue(LoginActivityStates.InvalidMobile)
            }
        } else {
            verifyOtp(mobile, otp)
        }
    }

    fun onResendOtpClicked() {
        mobile = mobileField.get().toString()
        if (isMobileValid(mobile)) {
            if (LoginSingleton.otpSentCount <= Constants.MAX_OTP_RETRY) {
                loginMutableStates.postValue(LoginActivityStates.StartTimer)
                sendOtp()
            } else {
                loginMutableStates.postValue(LoginActivityStates.MaxRetryReached)
            }
        } else {
            loginMutableStates.postValue(LoginActivityStates.InvalidMobile)
        }
    }

    private fun isMobileValid(mobile: String?): Boolean {
        if (!mobile.isNullOrEmpty() && mobile.length >= Constants.MIN_MOBILE_LENGTH) {
            val filedFirstCharacter = mobile.toCharArray()[0]
            if (filedFirstCharacter.equals(Constants.DIGIT_6, true) ||
                filedFirstCharacter.equals(Constants.DIGIT_7, true) ||
                filedFirstCharacter.equals(Constants.DIGIT_8, true) ||
                filedFirstCharacter.equals(Constants.DIGIT_9, true)
            ) {
                return true
            }
            return false
        }
        return false
    }

    private fun sendOtp() {
        Coroutines.main {
            try {
                handleSendOtpResponse()
            } catch (e: Exception) {
                loginMutableStates.postValue(LoginActivityStates.ShowError(e))
            }
        }
    }

    private suspend fun handleSendOtpResponse() {
        loginActivityRepository.sendOtp(mobile).data?.run {
            if (mobileNo.isNotEmpty()) {
                LoginSingleton.otpSentCount = LoginSingleton.otpSentCount + 1
                LoginSingleton.isOtpSent = true
                loginMutableStates.postValue(LoginActivityStates.OtpSent)
            }
        }
    }

    private fun verifyOtp(mobile: String, otp: String) {
        if (otp.isNotEmpty() && otp.length == Constants.OTP_LENGTH) {
            loginMutableStates.postValue(LoginActivityStates.ShowProgress)
            Coroutines.main {
                try {
                    handleVerifyOtpResponse(mobile, otp)
                } catch (e: Exception) {
                    loginMutableStates.postValue(LoginActivityStates.ShowError(e))
                }
            }
        } else {
            loginMutableStates.postValue(LoginActivityStates.InvalidOtp)
        }
    }

    private suspend fun handleVerifyOtpResponse(mobile: String, otp: String) {
        loginActivityRepository.verifyOtp(mobile, otp).data?.run {
            if (mobileNo.isNotEmpty()) {
                loginActivityRepository.saveUserDetails(
                    mobileNo, email, userName
                )
                loginMutableStates.postValue(LoginActivityStates.OtpVerified)
            }
        }
    }

    fun getLoginStates(): LiveData<LoginActivityStates> {
        return loginLiveStates
    }
}