package com.diagright.phlebo.ui.store;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.PreferenceManager;

import com.diagright.phlebo.BuildConfig;
import com.diagright.phlebo.Constants;
import com.diagright.phlebo.PhleboApplication;

/**
 * @author raghav
 */

public class SettingStore
{
    private static final String CONFIG = "config";
    private static final String DEV = "stag";
    private static final String AUTH = "auth";
    private static final String SCHEME = "scheme";
    private static final String HTTPS = "https";
    private static final String APP_VERSION = "appVersion";
    private static final String FCM_TOKEN = "fcm_token";
    private static final String PHLEBO_STARTED_ORDER_ID = "phlebo_started_order_id";

    @NonNull
    public static String getHost()
    {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(PhleboApplication.getContext());
        return sharedPreferences.getString(CONFIG, DEV);
    }

    public static String getAuthToken()
    {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(PhleboApplication.getContext());
        return sharedPreferences.getString(AUTH, Constants.EMPTY);
    }

    public static void clearAuthToken()
    {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(PhleboApplication.getContext()).edit();
        editor.remove(AUTH);
        editor.apply();

    }

    public static String getScheme()
    {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(PhleboApplication.getContext());
        return sharedPreferences.getString(SCHEME, HTTPS);
    }

    public static String getAppVersion()
    {
        Context context = PhleboApplication.getContext();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString(APP_VERSION, BuildConfig.VERSION_NAME);
    }

    @Nullable
    public static String getFcmToken() {
        return getSharedPreferences().getString(FCM_TOKEN, null);
    }

    public static void saveFcmToken(@NonNull String token) {
        getPrefEditor().putString(FCM_TOKEN, token).apply();
    }

    public static void clearFcmToken() {
        getPrefEditor().remove(FCM_TOKEN).apply();
    }

    @NonNull
    private static SharedPreferences getSharedPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(PhleboApplication.getContext());
    }

    @NonNull
    private static SharedPreferences.Editor getPrefEditor() {
        return getSharedPreferences().edit();
    }

}
