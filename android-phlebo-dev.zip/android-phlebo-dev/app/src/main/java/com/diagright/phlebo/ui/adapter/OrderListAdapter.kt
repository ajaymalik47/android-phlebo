package com.diagright.phlebo.ui.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.LayoutOrderItemBinding
import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.utility.TextUtility
import java.util.*


/**
 * @author by Vinayak Gupta
 */

class OrderListAdapter(
    private val orderList: List<OrderItem>,
    private val orderItemCallback: OrderItemCallback
) :
    RecyclerView.Adapter<OrderListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = DataBindingUtil.inflate<LayoutOrderItemBinding>(
            LayoutInflater.from(parent.context),
            R.layout.layout_order_item,
            parent,
            false
        )
        val viewHolder = ViewHolder(itemView)
        itemView.callCustomerButton.setOnClickListener {
            setCallCustomerOnClick(viewHolder.adapterPosition, parent.context)
        }

        itemView.viewOnMapButton.setOnClickListener {
            orderItemCallback.onNavigationButtonClicked(orderList[viewHolder.adapterPosition])
        }

        itemView.itemParent.setOnClickListener {
            setItemParentClick(
                viewHolder.adapterPosition
            )
        }
        itemView.button.setOnClickListener { orderItemCallback.onItemClick(orderList[viewHolder.adapterPosition]) }

        return viewHolder
    }

    private fun setCallCustomerOnClick(
        adapterPosition: Int,
        context: Context
    ) {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(
            String.format(
                Constants.URI_TELEPHONE,
                orderList[adapterPosition].contact
            )
        )
        context.startActivity(intent)
    }

    private fun setItemParentClick(adapterPosition: Int) {
        orderItemCallback.onItemClick(orderList[adapterPosition])
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(orderList[position])
    }

    class ViewHolder(private val itemBinding: LayoutOrderItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bindData(orderItem: OrderItem) {
            setUsername(orderItem)
            itemBinding.orderIdValue.text = orderItem.orderId
            itemBinding.dueText.text = orderItem.orderDue?.title
            itemBinding.orderStateValue.text = orderItem.orderState
            itemBinding.dueText.setTextColor(Color.parseColor(orderItem.orderDue?.color))
            itemBinding.timeValue.text = orderItem.slot
            if (orderItem.orderState.equals(Constants.OrderStates.SAMPLE_COLLECTED, true)) {
                itemBinding.dueText.visibility = View.GONE
            }
        }

        private fun setUsername(orderItem: OrderItem) {
            val username = orderItem.userName
            if (TextUtility.isNotEmpty(username)) {
                itemBinding.name.text = username
            } else {
                itemBinding.name.text = orderItem.contact
            }
        }
    }

    interface OrderItemCallback {
        fun onItemClick(orderItem: OrderItem)
        fun onNavigationButtonClicked(orderItem: OrderItem)
    }
}