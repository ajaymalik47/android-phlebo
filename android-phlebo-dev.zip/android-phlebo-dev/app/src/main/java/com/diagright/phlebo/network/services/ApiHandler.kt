package com.diagright.phlebo.network.services

import com.diagright.phlebo.network.RetrofitHandler

class ApiHandler {

    companion object {

        @JvmStatic
        val loginApi: LoginService by lazy {
            createRetrofitService<LoginService>()
        }

        fun makeLoginRequest(): LoginService {
            return createRetrofitService()
        }

        @JvmStatic
        val orderApi: OrderService by lazy {
            createRetrofitService<OrderService>()
        }

        @JvmStatic
        val commonApi: CommonService by lazy {
            createRetrofitService<CommonService>()
        }

        private inline fun <reified T> createRetrofitService() =
            RetrofitHandler.INSTANCE.create(T::class.java)
    }
}