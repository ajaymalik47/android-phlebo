package com.diagright.phlebo.network

import com.diagright.phlebo.network.model.ApiResponse
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Converter
import retrofit2.Converter.Factory
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type

/**
 * @author Vinayak
 */
class ApiRequestResponseConverterFactory(private val factory: GsonConverterFactory) : Factory() {

    override fun requestBodyConverter(type: Type, parameterAnnotations: Array<Annotation>, methodAnnotations: Array<Annotation>, retrofit: Retrofit): ApiRequestBodyConverter<Any> {
        val converter = factory.requestBodyConverter(type, parameterAnnotations, methodAnnotations, retrofit) as Converter<Any, RequestBody>
        return ApiRequestBodyConverter(converter)
    }

    override fun responseBodyConverter(type: Type, annotations: Array<Annotation>, retrofit: Retrofit): ApiResponseBodyConverter<Any> {
        if (type is ParameterizedType) {
            val converter = factory.responseBodyConverter(type, annotations, retrofit) as Converter<ResponseBody, ApiResponse<Any>>
            return ApiResponseBodyConverter(converter)
        } else {
            throw IllegalStateException("\${type.simpleName} return type must be parameterized as \${type.simpleName}<Foo> or \${type.simpleName}<? extends Foo>")
        }
    }
}