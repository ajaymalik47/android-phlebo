package com.diagright.phlebo.models

import androidx.annotation.Keep

/**
 * @author by Vinayak Gupta
 */
@Keep
data class UpdateOrderResponse(val updated: Boolean? = false)