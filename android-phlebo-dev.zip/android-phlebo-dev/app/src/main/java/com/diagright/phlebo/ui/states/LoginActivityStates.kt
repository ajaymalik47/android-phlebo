package com.diagright.phlebo.ui.states

/**
 * @author by Vinayak Gupta
 */
sealed class LoginActivityStates {

    object ShowProgress : LoginActivityStates()

    object InvalidMobile : LoginActivityStates()

    object InvalidOtp : LoginActivityStates()

    class ShowError(val exception: Throwable) : LoginActivityStates()

    object OtpSent : LoginActivityStates()

    object OtpVerified : LoginActivityStates()

    object MaxRetryReached : LoginActivityStates()

    object StartTimer : LoginActivityStates()
}