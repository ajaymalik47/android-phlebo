package com.diagright.phlebo.ui.domain

import com.diagright.phlebo.Constants
import com.diagright.phlebo.models.*
import com.diagright.phlebo.network.model.ApiResponse
import com.diagright.phlebo.network.services.ApiHandler

/**
 * @author by Vinayak Gupta
 */

class OrderDetailsRepository {

    suspend fun updateOrder(orderState: String, orderId: String): ApiResponse<UpdateOrderResponse> {
        val requestParams = HashMap<String, String>(2)
        requestParams[Constants.ORDER_STATE] = orderState
        requestParams[Constants.ORDER_ID] = orderId
        return ApiHandler.orderApi.updateOrder(requestParams)
    }

    suspend fun markSampleCollected(orderItem: OrderItem?): ApiResponse<UpdateOrderResponse> {
        lateinit var sampleCollectRequest: SampleCollectRequest
        orderItem?.run {
            val barcodeList = ArrayList<BarCode>(orderDetails.size)
            for (order in orderDetails) {
                val barcodeObject =
                    BarCode(order.patientInfo?.patientId, order.patientInfo?.barcode)
                barcodeList.add(barcodeObject)
            }
            sampleCollectRequest = SampleCollectRequest(
                orderId,
                Constants.OrderStates.SAMPLE_COLLECTED,
                price,
                barcodeList
            )
        }
        return ApiHandler.orderApi.sampleCollected(sampleCollectRequest)
    }

    suspend fun cancelOrder(orderId: String, patientIds: List<String>, reason: String): ApiResponse<Any> {
        return ApiHandler.orderApi.cancelOrders(CancelOrderRequestBody(orderId, patientIds, reason))
    }

    suspend fun getOrderCancellationReasons(): ApiResponse<CancelReasonDto> {
        return ApiHandler.orderApi.getCancellationReasons()
    }

    suspend fun notifyStateToUser(orderId: String, phleboState: String): ApiResponse<Any> {
        return ApiHandler.orderApi.notifyStateToUser(NotifyStateToUserRequest(orderId, phleboState))
    }

    suspend fun getOrders(): ApiResponse<List<OrderItem>> {
        return ApiHandler.orderApi.getOrdersList()
    }

}