package com.diagright.phlebo.models

import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.android.parcel.Parcelize

/**
 * @author by Vinayak Gupta
 */
@Parcelize
@Keep
data class Test(val price: Int?, val testName: String?) : Parcelable