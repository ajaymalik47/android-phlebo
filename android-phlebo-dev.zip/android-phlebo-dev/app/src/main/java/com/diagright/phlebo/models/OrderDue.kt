package com.diagright.phlebo.models

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.android.parcel.Parcelize

/**
 * @author by Vinayak Gupta
 */

@Parcelize
@Keep
data class OrderDue(val title: String?, val color: String?) : Parcelable