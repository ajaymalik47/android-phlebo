package com.diagright.phlebo.network

import android.content.Context
import com.diagright.phlebo.Constants
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.readystatesoftware.chuck.ChuckInterceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.ref.WeakReference

/**
 * @author Vinayak
 */
class RetrofitHandler {

    companion object {

        private lateinit var contextWeakReference: WeakReference<Context>

        fun init(context: Context) {
            contextWeakReference = WeakReference(context)
        }

        val INSTANCE: Retrofit by lazy {
            val retrofit = Retrofit.Builder()
                .baseUrl(Constants.RETROFIT_BASE_URL)
                .addConverterFactory(ApiRequestResponseConverterFactory(GsonConverterFactory.create()))
                .client(getOkHttpClient())
                .build()
            retrofit
        }

        private fun getOkHttpClient(): OkHttpClient {
            return OkHttpClient
                .Builder()
                .addNetworkInterceptor(OkhttpInterceptor())
                .addInterceptor(ChuckInterceptor(getContext()))
                .build()
        }

        private fun getGsonBuilder(): Gson {
            return GsonBuilder()
                .enableComplexMapKeySerialization()
                .setLenient()
                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                .create()
        }

        private fun getContext() = contextWeakReference.get()
    }
}