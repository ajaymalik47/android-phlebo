package com.diagright.phlebo.models

import androidx.annotation.Keep

/**
 * @author by Vinayak Gupta
 */

@Keep
data class BarCode(
    val patientId: String?,
    val barCode: String?
)