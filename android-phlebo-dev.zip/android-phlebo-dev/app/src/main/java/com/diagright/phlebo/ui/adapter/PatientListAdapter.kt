package com.diagright.phlebo.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.LayoutPatientItemBinding
import com.diagright.phlebo.models.OrderDetails
import com.diagright.phlebo.models.PatientInfo
import com.diagright.phlebo.models.Test

/**
 * @author by Vinayak Gupta
 */

class PatientListAdapter(
    private var orderDetailsList: List<OrderDetails>,
    private val callback: PatientListCallback
) :
    RecyclerView.Adapter<PatientListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = DataBindingUtil.inflate<LayoutPatientItemBinding>(
            LayoutInflater.from(parent.context), R.layout.layout_patient_item, parent, false
        )
        val viewHolder = ViewHolder(itemBinding)
        itemBinding.scancode.setOnClickListener {
            callback.startScanning(viewHolder.adapterPosition)
        }
        itemBinding.edit.setOnClickListener {
            callback.startScanning(viewHolder.adapterPosition)
        }
        return viewHolder
    }

    fun updateScanResult(orderList: List<OrderDetails>) {
        this.orderDetailsList = orderList
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return orderDetailsList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(orderDetailsList[position])
    }

    class ViewHolder(private val itemBinding: LayoutPatientItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bindData(orderDetails: OrderDetails) {
            setPatientDetails(orderDetails.patientInfo)
            createTestList(orderDetails.testInfo)
        }

        private fun setPatientDetails(patientInfo: PatientInfo?) {
            itemBinding.patientName.text = patientInfo?.name
            val patientDetails =
                StringBuilder(3).append(patientInfo?.gender).append(Constants.COMMA_WITH_WHITESPACE)
                    .append(patientInfo?.age).toString()
            itemBinding.patientDetails.text = patientDetails
            setBarcode(patientInfo?.barcode)
        }

        private fun setBarcode(barcode: String?) {
            if (barcode.isNullOrEmpty()) {
                itemBinding.scancode.text =
                    itemBinding.scancode.context.getString(R.string.scan_barcode)
                itemBinding.groupEditBarcode.visibility = View.GONE
                itemBinding.groupScanBarcode.visibility = View.VISIBLE
            } else {
                itemBinding.barcode.text = barcode
                itemBinding.groupScanBarcode.visibility = View.GONE
                itemBinding.groupEditBarcode.visibility = View.VISIBLE
            }
        }

        private fun createTestList(testInfo: List<Test>) {
            val listAdapter = TestListAdapter(testInfo)
            itemBinding.testItems.run {
                layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                adapter = listAdapter
            }
        }
    }

    interface PatientListCallback {
        fun startScanning(adapterPosition: Int)
    }
}