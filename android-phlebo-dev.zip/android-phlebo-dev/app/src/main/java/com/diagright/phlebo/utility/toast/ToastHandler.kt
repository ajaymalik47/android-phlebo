package com.diagright.phlebo.utility.toast

import android.content.Context
import android.widget.Toast
import com.diagright.phlebo.utility.UtilityClass

class ToastHandler {

    companion object {

        @JvmStatic
        val INSTANCE: ToastHandler by lazy {
            ToastHandler()
        }
    }

    fun showToast(context: Context, message: String, length: Int) {
        if (UtilityClass.isNougat()) {
            ToastCompat.makeText(context, message, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, message, length).show()
        }
    }

    fun getToastInstance(context: Context, message: String, length: Int): Toast {
        if (UtilityClass.isNougat()) {
            return ToastCompat.makeText(context, message, Toast.LENGTH_SHORT)
        } else {
            return Toast.makeText(context, message, length)
        }
    }
}