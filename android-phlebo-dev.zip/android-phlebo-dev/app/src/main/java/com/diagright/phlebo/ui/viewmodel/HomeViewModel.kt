package com.diagright.phlebo.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.diagright.phlebo.Coroutines
import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.ui.domain.HomeActivityRepository
import com.diagright.phlebo.ui.states.HomeActivityStates
import com.diagright.phlebo.utility.FcmSyncManager
import java.lang.Exception

class HomeViewModel(private val homeActivityRepository: HomeActivityRepository) : ViewModel() {

    private val homeActivityStates = MutableLiveData<HomeActivityStates>()

    init {
        loadOrderList()
        FcmSyncManager.syncSavedTokenWithServer()
    }

    fun loadOrderList() {
        Coroutines.main {
            try {
                homeActivityStates.postValue(HomeActivityStates.ShowProgress)
                val orderList: List<OrderItem> = homeActivityRepository.getOrders().data!!
                homeActivityStates.postValue(HomeActivityStates.DataLoaded(orderList))
            } catch (e: Exception) {
                homeActivityStates.postValue(HomeActivityStates.ShowError(e))
            }
        }
    }

    fun getHomeStates() = homeActivityStates
}