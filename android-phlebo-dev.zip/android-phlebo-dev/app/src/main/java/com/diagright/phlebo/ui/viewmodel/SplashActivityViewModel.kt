package com.diagright.phlebo.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.diagright.phlebo.ui.domain.SplashActivityRepository
import com.diagright.phlebo.ui.states.SplashActivityStates

/**
 * @author by Vinayak Gupta
 */
class SplashActivityViewModel(private val splashActivityRepository: SplashActivityRepository) :
    ViewModel() {

    private val splashMutableStates = MutableLiveData<SplashActivityStates>()
    private val splashLiveStates: LiveData<SplashActivityStates> get() = splashMutableStates

    init {
        checkUserLoginStatus()
    }

    private fun checkUserLoginStatus() {
        val isUserLoggedIn = splashActivityRepository.isUserLoggedIn()
        if (isUserLoggedIn) {
            splashMutableStates.postValue(SplashActivityStates.UserLoggedIn)
        } else {
            splashMutableStates.postValue(SplashActivityStates.UserNotLoggedIn)
        }
    }

    fun getSplashStates(): LiveData<SplashActivityStates> {
        return splashLiveStates
    }
}