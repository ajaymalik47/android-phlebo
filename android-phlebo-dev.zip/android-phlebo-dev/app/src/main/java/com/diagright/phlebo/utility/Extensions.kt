package com.diagright.phlebo.utility

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.diagright.phlebo.Constants
import java.util.*

fun Context.openMap(latitude: String, longitude: String) {
    val uri = String.format(
        Locale.US,
        Constants.MAP_NAVIGATION_URL,
        latitude,
        longitude
    )
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
    startActivity(intent)
}