package com.diagright.phlebo.network

import com.diagright.phlebo.Constants
import com.diagright.phlebo.ui.store.LoginStore
import okhttp3.Interceptor
import okhttp3.Response

/**
 * @author Vinayak
 */
class OkhttpInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val requestBuilder = originalRequest.newBuilder()
        LoginStore.getAuthToken()?.let { requestBuilder.addHeader(Constants.Headers.AUTHORIZATION_KEY, it) }
        val request = requestBuilder.build()
        val response = chain.proceed(request)
        checkResponseHeaders(response)
        return response
    }

    private fun checkResponseHeaders(response: Response) {
        val authToken = response.headers[Constants.Headers.AUTHORIZATION_KEY]
        if (!authToken.isNullOrEmpty()) {
            LoginStore.saveAuthToken(authToken)
        }
    }
}