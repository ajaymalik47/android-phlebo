package com.diagright.phlebo.network.model

import androidx.annotation.Keep

@Keep
data class ApiStatus(val code: Int = 0, val message: String? = null)