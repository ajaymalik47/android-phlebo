package com.diagright.phlebo.models

import androidx.annotation.Keep

/**
 * @author by Vinayak Gupta
 */

@Keep
data class SampleCollectRequest(
    val orderId: String?,
    val orderState: String,
    val amount: String,
    val barCodes: List<BarCode>
)