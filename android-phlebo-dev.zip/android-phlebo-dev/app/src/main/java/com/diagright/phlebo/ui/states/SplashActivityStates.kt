package com.diagright.phlebo.ui.states

/**
 * @author by Vinayak Gupta
 */
sealed class SplashActivityStates {

    object UserLoggedIn : SplashActivityStates()

    object UserNotLoggedIn : SplashActivityStates()
}