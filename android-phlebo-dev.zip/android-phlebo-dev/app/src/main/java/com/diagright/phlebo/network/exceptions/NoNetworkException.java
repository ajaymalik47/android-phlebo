package com.diagright.phlebo.network.exceptions;

public class NoNetworkException extends Exception
{
    public NoNetworkException(String errorMessage)
    {
        super(errorMessage);
    }
}
