package com.diagright.phlebo.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.diagright.phlebo.ui.domain.SplashActivityRepository
import com.diagright.phlebo.ui.viewmodel.SplashActivityViewModel

/**
 * @author by Vinayak Gupta
 */

class SplashActivityFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        val splashActivityRepository = SplashActivityRepository()
        return SplashActivityViewModel(splashActivityRepository) as T
    }
}