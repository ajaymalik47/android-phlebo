package com.diagright.phlebo.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.diagright.phlebo.Constants
import com.diagright.phlebo.Coroutines
import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.ui.domain.OrderDetailsRepository
import com.diagright.phlebo.ui.states.OrderDetailsState

/**
 * @author by Vinayak Gupta
 */
class OrderDetailsViewModel(private val orderDetailsRepository: OrderDetailsRepository) :
    ViewModel() {

    private var orderItem: OrderItem? = null
    private val orderDetailsStates = MutableLiveData<OrderDetailsState>()
    private val isOrderUpdated = MutableLiveData<Boolean>()

    fun setOrderItem(orderItem: OrderItem?) {
        this.orderItem = orderItem
    }

    fun getOrderItem() = orderItem

    fun onAcceptClicked() {
        if (orderItem?.orderState == Constants.OrderStates.PHLEBO_ASSIGNED) {
            if (Constants.PAYMENT_MODE_COD.equals(orderItem?.paymentMode, true)) {
                orderDetailsStates.postValue(OrderDetailsState.ShowDialog)
            } else {
                markSampleCollected()
            }
        } else {
            orderDetailsStates.postValue(OrderDetailsState.ShowLoader)
            updateOrder(Constants.OrderStates.SAMPLE_IN_LAB, orderItem?.orderId ?: "")
        }
    }

    private fun markSampleCollected() {
        Coroutines.main {
            try {
                val response = orderDetailsRepository.markSampleCollected(orderItem)
                val message: String = response.status?.message!!
                response.data.run {
                    orderDetailsStates.postValue(OrderDetailsState.OrderUpdated(message))
                }
            } catch (e: Throwable) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

    fun updateOrder(orderState: String, orderId: String) {
        Coroutines.main {
            try {
                val response = orderDetailsRepository.updateOrder(orderState, orderId)
                val message: String = response.status?.message!!
                response.data?.run {
                    if (updated!!) {
                        orderDetailsStates.postValue(OrderDetailsState.OrderUpdated(message))
                    } else {
                        orderDetailsStates.postValue(OrderDetailsState.ShowToast(Constants.SOME_ERROR_OCCURRED))
                    }
                }
            } catch (e: Exception) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

    fun onAmountCollected() {
        markSampleCollected()
    }

    fun onCallActionClicked() {
        orderDetailsStates.postValue(OrderDetailsState.CallAction)
    }

    fun onViewMapClicked() {
        orderDetailsStates.postValue(OrderDetailsState.ViewMap)
    }

    fun getOrderDetailsState() = orderDetailsStates
    fun isOrderUpdated() = isOrderUpdated

    fun getCancelOrderReasons() {
        Coroutines.main {
            try {
                val response = orderDetailsRepository.getOrderCancellationReasons()
                val message: String = response.status?.message!!
                response.data?.cancelReason?.let {
                    orderDetailsStates.postValue(OrderDetailsState.ShowCancellationReasons(it))
                } ?: run {
                    orderDetailsStates.postValue(OrderDetailsState.ShowToast(message))
                }
            } catch (e: Exception) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

    fun cancelOrderWithReason(reason: String) {
        Coroutines.main {
            try {
                val response = orderDetailsRepository.cancelOrder(
                    orderItem?.orderId ?: "",
                    orderItem?.getPatientIds() ?: emptyList(),
                    reason)
                val message: String = response.status?.message!!
                response.data?.let {
                    orderDetailsStates.postValue(OrderDetailsState.OrderCancelled(message))
                } ?: run {
                    orderDetailsStates.postValue(OrderDetailsState.ShowToast(message))
                }
            } catch (e: Exception) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

    fun refreshOrder() {
        Coroutines.main {
            try {
                orderDetailsStates.postValue(OrderDetailsState.ShowLoader)
                val response = orderDetailsRepository.getOrders()
                val message: String = response.status?.message!!
                response.data?.forEach {
                    if (it.orderId == orderItem?.orderId) {
                        this.orderItem = it
                        orderDetailsStates.postValue(OrderDetailsState.OrderStateUpdated(it))
                        isOrderUpdated.value = true
                        return@forEach
                    }
                } ?: run {
                    orderDetailsStates.postValue(OrderDetailsState.ShowToast(message))
                }
            } catch (e: Exception) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

    fun onNotifyUserClicked() {
        Coroutines.main {
            try {
                val phleboState =
                    if (orderItem?.phleboStarted.isNullOrEmpty() && orderItem?.phleboReached.isNullOrEmpty()) "phleboStarted" else "phleboReached"
                orderDetailsStates.postValue(OrderDetailsState.ShowLoader)
                val response =
                    orderDetailsRepository.notifyStateToUser(orderItem?.orderId ?: "", phleboState)
                val message: String = response.status?.message!!
                response.data?.let {
                    refreshOrder()
                } ?: run {
                    orderDetailsStates.postValue(OrderDetailsState.ShowToast(message))
                }
            } catch (e: Exception) {
                orderDetailsStates.postValue(OrderDetailsState.ShowError(e))
            }
        }
    }

}