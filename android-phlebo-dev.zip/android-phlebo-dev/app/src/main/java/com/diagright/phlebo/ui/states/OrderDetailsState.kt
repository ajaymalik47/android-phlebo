package com.diagright.phlebo.ui.states

import com.diagright.phlebo.models.OrderItem

/**
 * @author by Vinayak Gupta
 */
sealed class OrderDetailsState {

    object ShowLoader : OrderDetailsState()

    object HideLoader : OrderDetailsState()

    class ShowError(val throwable: Throwable) : OrderDetailsState()

    class ShowToast(val message: String) : OrderDetailsState()

    class OrderUpdated(val message: String) : OrderDetailsState()

    class OrderStateUpdated(val orderItem: OrderItem) : OrderDetailsState()

    object CallAction : OrderDetailsState()

    object ViewMap : OrderDetailsState()

    object ShowDialog : OrderDetailsState()

    class ShowCancellationReasons(val reasons: List<String>) : OrderDetailsState()

    class OrderCancelled(val message: String) : OrderDetailsState()
}