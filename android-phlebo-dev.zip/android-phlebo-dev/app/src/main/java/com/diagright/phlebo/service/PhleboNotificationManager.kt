package com.diagright.phlebo.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.diagright.imageloader.ImageLoader
import com.diagright.imageloader.implementation.ImageLoaderImpl
import com.diagright.phlebo.R
import com.diagright.phlebo.service.FirebaseMessagingService.Companion.CHANNEL_ID

class PhleboNotificationManager constructor(private val context: Context) {

    private val imageLoader: ImageLoader by lazy { ImageLoaderImpl() }

    fun handleNotification(data: Map<String, String>) {
        if (data["notificationType"] == "image") {
            handleImageNotification(
                NotificationType.Image(
                    data["title"] ?: "",
                    data["message"] ?: "",
                    data["icon"] ?: "",
                    data["image"] ?: "",
                    data["deepLink"] ?: ""
                )
            )
        } else if (data["notificationType"] == "text") {
            showTextNotification(
                NotificationType.Text(
                    data["title"] ?: "",
                    data["message"] ?: "",
                    data["body"] ?: "",
                    data["icon"] ?: "",
                    data["deepLink"] ?: ""
                )
            )
        }
    }

    private fun handleImageNotification(data: NotificationType.Image) {
        imageLoader.downloadAsBitmap(context, data.image) { image ->
            image?.let {
                imageLoader.downloadAsBitmap(context, data.icon) { icon ->
                    icon?.let {
                        showImageNotification(image, icon, data)
                    }
                }
            }
        }
    }

    private fun showImageNotification(image: Bitmap, icon: Bitmap, data: NotificationType.Image) {
        val notificationBuilder = getNotificationBuilder(data)
            .setLargeIcon(icon)
            .setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(image)
                    .bigLargeIcon(null)
            )
        showNotification(notificationBuilder.build())
    }

    private fun showTextNotification(data: NotificationType.Text) {
        imageLoader.downloadAsBitmap(context, data.icon) { icon ->
            val notificationBuilder = getNotificationBuilder(data)
                .setStyle(NotificationCompat.BigTextStyle().bigText(data.body))
            if (icon != null) {
                notificationBuilder.setLargeIcon(icon)
            }
            showNotification(notificationBuilder.build())
        }
    }

    private fun getNotificationBuilder(data: NotificationType): NotificationCompat.Builder {
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(data.title)
            .setContentText(data.message)
            .setSmallIcon(R.drawable.ic_launcher)
            .setColor(context.resources.getColor(R.color.colorPrimary))
            .setColorized(true)
            .setAutoCancel(true)
            .setContentIntent(getPendingIntentForDeepLink(data.deepLink))
    }

    private fun showNotification(notification: Notification) {
        val manager = NotificationManagerCompat.from(context)
        manager.notify(/*notification id*/0, notification)
    }

    private fun getPendingIntentForDeepLink(deepLink: String): PendingIntent {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(deepLink)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_ONE_SHOT)
    }

    private sealed class NotificationType(
        val title: String,
        val message: String,
        val icon: String,
        val deepLink: String
    ) {

        class Text(
            title: String,
            message: String,
            val body: String,
            icon: String,
            deepLink: String
        ) : NotificationType(title, message, icon, deepLink)

        class Image(
            title: String,
            message: String,
            icon: String,
            val image: String,
            deepLink: String
        ) : NotificationType(title, message, icon, deepLink)

    }

}