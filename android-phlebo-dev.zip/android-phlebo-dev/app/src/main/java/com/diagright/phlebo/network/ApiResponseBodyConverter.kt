package com.diagright.phlebo.network

import com.diagright.phlebo.Constants
import com.diagright.phlebo.network.exceptions.CustomHttpException
import com.diagright.phlebo.network.exceptions.UnauthorizedAccessExceptionCustom
import com.diagright.phlebo.network.model.ApiResponse
import okhttp3.ResponseBody
import org.json.JSONException
import retrofit2.Converter
import java.io.IOException

/**
 * @author Vinayak
 */
class ApiResponseBodyConverter<T> internal constructor(private val converter: Converter<ResponseBody, ApiResponse<T>>) :
    Converter<ResponseBody, ApiResponse<T>> {

    companion object {
        private const val SUCCESS = 200
        private const val RESPONSE_CODE_UNAUTHORIZED_ACCESS_ = 402
        private const val RESPONSE_CODE_UNAUTHORIZED_ACCESS = 403
    }

    @Throws(IOException::class)
    override fun convert(value: ResponseBody): ApiResponse<T> {
        val response = converter.convert(value)
        response?.let {
            when (it.status?.code) {
                SUCCESS -> return it
                RESPONSE_CODE_UNAUTHORIZED_ACCESS -> throw UnauthorizedAccessExceptionCustom(it.status?.message)
                RESPONSE_CODE_UNAUTHORIZED_ACCESS_ -> throw UnauthorizedAccessExceptionCustom(it.status?.message)
                else -> throw CustomHttpException(it.status?.message)
            }
        } ?: run {
            throw JSONException(Constants.JSON_PARSER_EXCEPTION)
        }
    }
}