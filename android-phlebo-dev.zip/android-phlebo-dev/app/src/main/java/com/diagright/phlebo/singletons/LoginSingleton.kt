package com.diagright.phlebo.singletons

/**
 * @author by Vinayak Gupta
 */
object LoginSingleton {

    var isOtpSent: Boolean = false
    var otpSentCount: Int = 1
}