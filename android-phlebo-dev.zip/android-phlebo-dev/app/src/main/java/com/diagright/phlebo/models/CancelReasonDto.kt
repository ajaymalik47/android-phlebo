package com.diagright.phlebo.models

import androidx.annotation.Keep

@Keep
data class CancelReasonDto(val cancelReason: List<String>? = null)