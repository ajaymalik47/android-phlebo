package com.diagright.phlebo.utility

/**
 * @author by Vinayak Gupta
 */

object IntentAction {
    const val ACTION_AUTHENTICATION =
        "com.diagright.phlebo.ui.controller.ACTION_AUTHENTICATION"
}