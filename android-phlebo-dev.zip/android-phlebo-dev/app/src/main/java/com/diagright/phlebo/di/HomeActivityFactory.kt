package com.diagright.phlebo.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.diagright.phlebo.ui.domain.HomeActivityRepository
import com.diagright.phlebo.ui.viewmodel.HomeViewModel

/**
 * @author by Vinayak Gupta
 */
class HomeActivityFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        val homeActivityRepository = HomeActivityRepository()
        return HomeViewModel(homeActivityRepository) as T
    }
}