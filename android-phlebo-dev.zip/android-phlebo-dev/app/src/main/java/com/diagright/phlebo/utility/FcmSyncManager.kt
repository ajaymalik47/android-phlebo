package com.diagright.phlebo.utility

import android.os.Build
import android.provider.Settings
import com.diagright.phlebo.Constants
import com.diagright.phlebo.Coroutines
import com.diagright.phlebo.PhleboApplication
import com.diagright.phlebo.R
import com.diagright.phlebo.network.services.ApiHandler
import com.diagright.phlebo.ui.store.SettingStore

object FcmSyncManager {

    fun syncTokenWithServer(token: String) {
        Coroutines.main {
            try {
                val deviceDetails = getDeviceDetails()
                deviceDetails[Constants.FCM_TOKEN] = token
                ApiHandler.commonApi.updateDeviceDetails(deviceDetails)
                SettingStore.clearFcmToken()
            } catch (exc: Exception) {
                syncFailed(token)
            }
        }
    }

    fun syncSavedTokenWithServer() {
        val token = SettingStore.getFcmToken()
        if (!token.isNullOrEmpty()) {
            Coroutines.main {
                try {
                    val deviceDetails = getDeviceDetails()
                    deviceDetails[Constants.FCM_TOKEN] = token
                    ApiHandler.commonApi.updateDeviceDetails(deviceDetails)
                    SettingStore.clearFcmToken()
                } catch (exc: Exception) {
                    syncFailed(token)
                }
            }
        }
    }

    private fun syncFailed(token: String) {
        SettingStore.saveFcmToken(token)
    }

    private fun getDeviceDetails(): MutableMap<String, String> {
        val context = PhleboApplication.getContext()
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        val osVersion = Build.VERSION.RELEASE
        val appName = context.getString(R.string.app_name)
        val deviceId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        )
        return mutableMapOf(
            "deviceBrand" to manufacturer,
            "deviceModel" to model,
            "osVersion" to osVersion,
            "appName" to appName,
            "deviceId" to deviceId
        )
    }

}