package com.diagright.phlebo.ui.domain

import com.diagright.phlebo.ui.store.LoginStore

/**
 * @author by Vinayak Gupta
 */
class SplashActivityRepository {
    fun isUserLoggedIn(): Boolean {
        return LoginStore.isUserLoggedIn()
    }
}