package com.diagright.phlebo.ui.store

import android.content.Context
import android.content.SharedPreferences
import com.diagright.phlebo.Constants
import com.diagright.phlebo.PhleboApplication

/**
 * @author by Vinayak Gupta
 */
object LoginStore {

    private const val AUTH_PREFERENCE = "auth_pref"
    private const val AUTH_TOKEN = "auth_token"
    private const val USER_EMAIL = "email"
    private const val USER_MOBILE = "mobile"
    private const val USER_NAME = "name"

    private val authPreference: SharedPreferences
        get() = PhleboApplication.getContext().getSharedPreferences(
            AUTH_PREFERENCE,
            Context.MODE_PRIVATE
        )

    private val authPreferenceEditor: SharedPreferences.Editor
        get() = authPreference.edit()

    fun saveAuthToken(authtoken: String) {
        authPreferenceEditor.putString(AUTH_TOKEN, authtoken).apply()
    }

    fun saveUserDetails(mobileNo: String, email: String?, name: String?) {
        authPreferenceEditor
            .putString(USER_MOBILE, mobileNo)
            .putString(USER_EMAIL, email)
            .putString(USER_NAME, name)
            .apply()
    }

    fun getAuthToken(): String? {
        return authPreference.getString(AUTH_TOKEN, Constants.EMPTY)
    }

    fun isUserLoggedIn(): Boolean {
        if (!getAuthToken().isNullOrEmpty()) {
            return true
        }
        return false
    }

    fun logoutUser() {
        authPreferenceEditor.clear().apply()
    }

    fun getEmail(): String? {
        return authPreference.getString(USER_EMAIL, Constants.EMPTY)
    }

    fun getMobile(): String? {
        return authPreference.getString(USER_MOBILE, Constants.EMPTY)
    }

    fun getName(): String? {
        return authPreference.getString(USER_NAME, Constants.EMPTY)
    }
}