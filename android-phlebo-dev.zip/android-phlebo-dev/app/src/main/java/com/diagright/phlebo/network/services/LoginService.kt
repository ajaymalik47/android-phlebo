package com.diagright.phlebo.network.services

import com.diagright.phlebo.models.CreateUserResponse
import com.diagright.phlebo.network.model.ApiResponse
import retrofit2.http.Body
import retrofit2.http.POST

interface LoginService {

    @POST("users/v1/user")
    suspend fun sendOtp(
        @Body requestBody: Map<String, String>
    ): ApiResponse<CreateUserResponse>

    @POST("users/v1/user/otp/verify")
    suspend fun verifyOtp(
        @Body requestBody: Map<String, String>
    ): ApiResponse<CreateUserResponse>
}