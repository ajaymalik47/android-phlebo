package com.diagright.phlebo.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.diagright.phlebo.ui.domain.LoginActivityRepository
import com.diagright.phlebo.ui.domain.OrderDetailsRepository
import com.diagright.phlebo.ui.domain.SplashActivityRepository
import com.diagright.phlebo.ui.viewmodel.LoginViewModel
import com.diagright.phlebo.ui.viewmodel.OrderDetailsViewModel
import com.diagright.phlebo.ui.viewmodel.SplashActivityViewModel

/**
 * @author by Vinayak Gupta
 */

class OrderDetailsActivityFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        val orderDetailsRepository = OrderDetailsRepository()
        return OrderDetailsViewModel(orderDetailsRepository) as T
    }
}