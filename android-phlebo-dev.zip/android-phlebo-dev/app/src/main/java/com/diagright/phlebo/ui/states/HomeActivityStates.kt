package com.diagright.phlebo.ui.states

import com.diagright.phlebo.models.OrderItem
import java.lang.Exception

/**
 * @author by Vinayak Gupta
 */
sealed class HomeActivityStates {

    class DataLoaded(val ordersList: List<OrderItem>) : HomeActivityStates()

    object ShowProgress : HomeActivityStates()

    object HideProgress : HomeActivityStates()

    class ShowError(val exception: Exception) : HomeActivityStates()
}