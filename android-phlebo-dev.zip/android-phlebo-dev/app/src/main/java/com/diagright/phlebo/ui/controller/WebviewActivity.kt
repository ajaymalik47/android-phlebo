package com.diagright.phlebo.ui.controller

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import kotlinx.android.synthetic.main.activity_webview.*

/**
 * @author by Vinayak Gupta
 */
class WebviewActivity : AppCompatActivity() {

    companion object {

        fun startActivity(activity: Activity, url: String) {
            val intent = Intent(activity, WebviewActivity::class.java)
            intent.putExtra(Constants.INTENT_WEBVIEW_URL, url)
            activity.startActivity(intent)
        }
    }

    private lateinit var toolbar: Toolbar
    private lateinit var webView: WebView
    private var url: String? = Constants.EMPTY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview)
        toolbar = findViewById(R.id.toolbar)
        webView = findViewById(R.id.webview)
        init()
    }

    private fun init() {
        setToolbar()
        extractIntent()
        loadUrl()
    }

    private fun setToolbar() {
        toolbar.setNavigationOnClickListener { onBackPressed() }
        setSupportActionBar(toolbar)
        supportActionBar?.run {
            setDisplayShowHomeEnabled(true)
            setDisplayShowTitleEnabled(true)
        }
    }

    private fun extractIntent() {
        url = intent?.getStringExtra(Constants.INTENT_WEBVIEW_URL)
    }

    private fun loadUrl() {
        webview.loadUrl(url)
    }
}