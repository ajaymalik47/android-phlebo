package com.diagright.phlebo

import android.app.Application
import android.content.Context
import com.diagright.phlebo.network.RetrofitHandler

/**
 * @author by Vinayak Gupta
 */
class PhleboApplication : Application() {

    companion object {
        private lateinit var context: Context

        @JvmStatic
        fun init(context: Context) {
            Companion.context = context
        }

        @JvmStatic
        fun getContext(): Context = context
    }

    override fun onCreate() {
        super.onCreate()
        init(applicationContext)
        RetrofitHandler.init(applicationContext)
    }
}