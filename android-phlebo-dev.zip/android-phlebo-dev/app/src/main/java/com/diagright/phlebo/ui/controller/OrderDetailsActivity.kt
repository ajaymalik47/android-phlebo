package com.diagright.phlebo.ui.controller

import ExceptionHandler
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.core.view.forEach
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.ActivityOrderDetailsBinding
import com.diagright.phlebo.di.OrderDetailsActivityFactory
import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.ui.adapter.PatientListAdapter
import com.diagright.phlebo.ui.states.OrderDetailsState
import com.diagright.phlebo.ui.viewmodel.OrderDetailsViewModel
import com.diagright.phlebo.utility.UtilityClass
import com.diagright.phlebo.utility.toast.ToastHandler
import okhttp3.internal.notify
import java.util.*

class OrderDetailsActivity : AppCompatActivity(), PatientListAdapter.PatientListCallback,
    AlertDialogFragment.AlertDialogCallback {

    private var adapterPosition: Int = 0
    private lateinit var binding: ActivityOrderDetailsBinding
    private lateinit var viewModel: OrderDetailsViewModel

    companion object {
        const val REQ_CODE_SCANNER = 1001
        const val RESULT_CODE_ORDER_UPDATED = "RESULT_CODE_ORDER_UPDATED"

        fun startActivity(activity: Activity, orderItem: OrderItem, reqCode: Int) {
            val intent = Intent(activity, OrderDetailsActivity::class.java)
            intent.putExtra(Constants.INTENT_ORDER_DATA, orderItem)
            activity.startActivityForResult(intent, reqCode)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DataBindingUtil.setContentView<ActivityOrderDetailsBinding>(
            this,
            R.layout.activity_order_details
        ).apply {
            lifecycleOwner = this@OrderDetailsActivity
            binding = this
        }
        init()
    }

    private fun init() {
        setupToolbar()
        setViewModel()
        observeData()
        updateViewModel()
        setDataInFields()
    }

    private fun setupToolbar() {
        supportActionBar?.run {
            setDisplayShowHomeEnabled(true)
        }
        setSupportActionBar(binding.orderDetailToolbar)
        binding.orderDetailToolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun updateViewModel() {
        val orderItem = intent?.getParcelableExtra(Constants.INTENT_ORDER_DATA) as OrderItem
        viewModel.setOrderItem(orderItem)
    }

    private fun setViewModel() {
        val orderDetailsFactory = OrderDetailsActivityFactory()
        viewModel =
            ViewModelProvider(this, orderDetailsFactory).get(OrderDetailsViewModel::class.java)
        binding.orderDetailViewModel = viewModel
    }

    private fun observeData() {
        viewModel.getOrderDetailsState().observe(this, Observer {
            when (it) {
                is OrderDetailsState.ShowLoader -> showProgress()
                is OrderDetailsState.ShowToast -> showToast(it.message)
                is OrderDetailsState.HideLoader -> hideProgress()
                is OrderDetailsState.ShowError -> showError(it.throwable)
                is OrderDetailsState.OrderUpdated -> orderUpdated(it.message)
                is OrderDetailsState.CallAction -> onCallActionCalled()
                is OrderDetailsState.ViewMap -> onViewMapCalled()
                is OrderDetailsState.ShowDialog -> showPriceDialog()
                is OrderDetailsState.ShowCancellationReasons -> showCancellationReasons(it.reasons)
                is OrderDetailsState.OrderCancelled -> orderCancelled(it.message)
                is OrderDetailsState.OrderStateUpdated -> updateUI(it.orderItem)
            }
        })
        viewModel.isOrderUpdated().observe(this, Observer {
            if (it) {
                setOrderUpdatedResult()
            }
        })
    }

    private fun setOrderUpdatedResult() {
        setResult(Activity.RESULT_OK, Intent().apply {
            putExtra(RESULT_CODE_ORDER_UPDATED, true)
        })
    }

    private fun updateUI(orderItem: OrderItem){
        hideProgress()
        setDataInFields()
    }

    private fun orderCancelled(message: String) {
        showToast(message)
        exitActivity()
    }

    private fun showCancellationReasons(reasons: List<String>) {
        hideProgress()
        val alertDialog =
            AlertDialog.Builder(this)
                .setSingleChoiceItems(reasons.toTypedArray(), -1) { dialog, index ->
                    showProgress()
                    viewModel.cancelOrderWithReason(reasons[index])
                    dialog.dismiss()
                }
        val alert = alertDialog.create()
        alert.show()
    }

    private fun showProgress() {
        binding.progress.visibility = View.VISIBLE
    }

    private fun hideProgress() {
        binding.progress.visibility = View.GONE
    }

    private fun showError(throwable: Throwable) {
        hideProgress()
        ExceptionHandler.handle(throwable, this)
    }

    private fun orderUpdated(message: String) {
        showToast(message)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun onCallActionCalled() {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(
            String.format(
                Constants.URI_TELEPHONE, viewModel.getOrderItem()?.contact
            )
        )
        startActivity(intent)
    }

    private fun onViewMapCalled() {
        if (viewModel.getOrderItem()?.navigation != null) {
            val uri = String.format(
                Locale.US, Constants.MAP_NAVIGATION_URL,
                viewModel.getOrderItem()?.navigation?.latitude, viewModel.getOrderItem()?.navigation?.longitude
            )
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            startActivity(intent)
        } else {
            showToast(getString(R.string.no_location_for_user))
        }
    }

    private fun showPriceDialog() {
        val alertDialogFragment =
            AlertDialogFragment.newInstance(viewModel.getOrderItem()?.price, viewModel.getOrderItem()?.displayPrice)
        val fragmentTransaction =
            supportFragmentManager.beginTransaction()
        fragmentTransaction.add(alertDialogFragment, AlertDialogFragment::class.java.simpleName)
        fragmentTransaction.commitAllowingStateLoss()
    }

    private fun setDataInFields() {
        viewModel.getOrderItem()?.run {
            binding.username.text = userName
            binding.orderId.text = "Order ID: $orderId"
            binding.orderStateValue.text = orderState
            binding.addressValue.text = address
            binding.emailValue.text = email
            binding.timeValue.text = slot
            orderDue?.run {
                binding.state.text = title
                binding.state.setTextColor(Color.parseColor(color))
            }
            binding.patientList.layoutManager =
                LinearLayoutManager(this@OrderDetailsActivity, LinearLayoutManager.VERTICAL, false)
            binding.patientList.adapter =
                PatientListAdapter(orderDetails, this@OrderDetailsActivity)
            configureAcceptCta(orderState)
            configurePricing(paymentMode, displayPrice)
            configureNotifyUserButton(this)
        }
    }

    private fun configureNotifyUserButton(orderItem: OrderItem) {
        if (orderItem.phleboStarted.isNullOrEmpty() && orderItem.phleboReached.isNullOrEmpty()) {
            //Initial Stage
            binding.notifyUserButton.visibility = View.VISIBLE
            binding.notifyUserButton.text = getString(R.string.phlebo_started)
        } else if (orderItem.phleboReached.isNullOrEmpty()) {
            binding.notifyUserButton.visibility = View.VISIBLE
            binding.notifyUserButton.text = getString(R.string.phlebo_reached)
        } else {
            binding.notifyUserButton.visibility = View.GONE
        }
    }

    private fun configurePricing(paymentMode: String, displayPrice: String) {
        if (Constants.PAYMENT_MODE_COD.equals(paymentMode, true)) {
            binding.priceContainer.visibility = View.VISIBLE
            binding.price.text = displayPrice
        } else {
            binding.priceContainer.visibility = View.GONE
        }
    }

    private fun configureAcceptCta(orderState: String) {
        when (orderState) {
            Constants.OrderStates.PHLEBO_ASSIGNED -> {
                binding.buttonParent.visibility = View.VISIBLE
                binding.button.text = "SAMPLE COLLECTED"
            }
            Constants.OrderStates.SAMPLE_COLLECTED -> {
                binding.buttonParent.visibility = View.VISIBLE
                binding.button.text = "SAMPLE IN LAB"
            }
            else -> {
                binding.buttonParent.visibility = View.GONE
            }
        }
    }

    private fun isValidState(orderState: String): Boolean {
        if (Constants.OrderStates.SCHEDULED.equals(orderState, true) ||
            Constants.OrderStates.PHLEBO_ASSIGNED.equals(orderState, true)
        ) {
            return true
        }
        return false
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        configureMenuState(menu)
        return true
    }

    @SuppressLint("RestrictedApi")
    private fun configureMenuState(menu: Menu) {
        if (isValidState(viewModel.getOrderItem()?.orderState!!)) {
            menuInflater.inflate(R.menu.order_details_menu, menu)
            if (menu is MenuBuilder) {
                val m: MenuBuilder = menu
                m.setOptionalIconsVisible(true)
            }
            menu.forEach {
                if (it.itemId == R.id.action_refresh) {
                    it.isVisible = shouldShowRefreshOption()
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_cancel -> cancelOrder()
            R.id.action_reschedule -> updateState(Constants.OrderStates.RESCHEDULE)
            R.id.action_refresh -> viewModel.refreshOrder()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateState(orderState: String) {
        viewModel.getOrderItem()?.orderId?.let { id ->
            showProgress()
            viewModel.updateOrder(orderState, id)
        }
    }

    private fun cancelOrder() {
        showProgress()
        viewModel.getCancelOrderReasons()
    }

    private fun showToast(message: String) {
        hideProgress()
        ToastHandler.INSTANCE.showToast(
            this@OrderDetailsActivity,
            message, Toast.LENGTH_SHORT
        )
    }

    override fun startScanning(adapterPosition: Int) {
        this.adapterPosition = adapterPosition
        BarcodeReaderActivity.startActivityForResult(this, REQ_CODE_SCANNER)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQ_CODE_SCANNER && data != null) {
                handleResult(data)
            }
        } else {
            showToast(Constants.UNABLE_TO_SCAN)
        }
    }

    private fun checkIfAllScansAreDone(): Boolean {
        viewModel.getOrderItem()?.orderDetails?.run {
            for (order in this) {
                if (order.patientInfo?.barcode.isNullOrEmpty()) {
                    return false
                }
            }
        }
        return true
    }

    private fun handleResult(data: Intent) {
        updateList(data)
        binding.button.isEnabled = checkIfAllScansAreDone()
    }

    private fun updateList(data: Intent) {
        val patientListAdapter = binding.patientList.adapter as PatientListAdapter
        viewModel.getOrderItem()?.orderDetails?.run {
            get(adapterPosition).patientInfo?.barcode =
                data.getStringExtra(Constants.INTENT_SCANNED_RESULT)
            patientListAdapter.updateScanResult(this)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        exitActivity()
    }

    private fun exitActivity() {
        UtilityClass.overrideExitTransition(this)
        finish()
    }

    override fun onAmountCollected() {
        showProgress()
        viewModel.onAmountCollected()
    }

    private fun shouldShowRefreshOption(): Boolean {
        val order = intent?.getParcelableExtra(Constants.INTENT_ORDER_DATA) as OrderItem?
        return order?.paymentMode == "COD"
    }

}
