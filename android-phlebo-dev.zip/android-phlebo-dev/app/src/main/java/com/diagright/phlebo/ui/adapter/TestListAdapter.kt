package com.diagright.phlebo.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.LayoutTestItemBinding
import com.diagright.phlebo.models.Test

/**
 * @author by Vinayak Gupta
 */

class TestListAdapter(private val testList: List<Test>) :
    RecyclerView.Adapter<TestListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = DataBindingUtil.inflate<LayoutTestItemBinding>(
            LayoutInflater.from(parent.context), R.layout.layout_test_item, parent, false
        )
        val viewHolder = ViewHolder(itemBinding)
        return viewHolder
    }

    override fun getItemCount(): Int {
        return testList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(testList[position].testName)
    }

    class ViewHolder(private val itemBinding: LayoutTestItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bindData(testName: String?) {
            itemBinding.testname.text = testName
        }
    }
}