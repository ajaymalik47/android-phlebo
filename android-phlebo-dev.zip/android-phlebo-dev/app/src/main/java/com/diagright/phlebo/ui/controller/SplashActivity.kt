package com.diagright.phlebo.ui.controller

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.diagright.phlebo.di.SplashActivityFactory
import com.diagright.phlebo.ui.states.SplashActivityStates
import com.diagright.phlebo.ui.viewmodel.SplashActivityViewModel
import com.diagright.phlebo.utility.UtilityClass

/**
 * @author by Vinayak Gupta
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val splashActivityFactory = SplashActivityFactory()
        val viewModel =
            ViewModelProvider(this, splashActivityFactory).get(SplashActivityViewModel::class.java)
        observeData(viewModel)
    }

    private fun observeData(viewModel: SplashActivityViewModel) {
        viewModel.getSplashStates().observe(this, Observer {
            when (it) {
                is SplashActivityStates.UserNotLoggedIn -> handleNotLoggedInUser()
                is SplashActivityStates.UserLoggedIn -> handleLoggedInUser()
            }
        })
    }

    private fun handleNotLoggedInUser() {
        startActivity(Intent(this, LoginActivity::class.java))
        exitActivity()
    }

    private fun handleLoggedInUser() {
        startActivity(Intent(this, HomeActivity::class.java))
        exitActivity()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        exitActivity()
    }

    private fun exitActivity() {
        UtilityClass.overrideExitTransition(this)
        finish()
    }
}