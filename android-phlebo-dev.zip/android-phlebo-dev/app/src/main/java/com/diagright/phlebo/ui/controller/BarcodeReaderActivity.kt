package com.diagright.phlebo.ui.controller

import android.Manifest.permission.CAMERA
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.ActivityBarcodeBinding
import com.diagright.phlebo.utility.UtilityClass
import com.google.zxing.Result
import me.dm7.barcodescanner.zxing.ZXingScannerView


/**
 * @author by Vinayak Gupta
 */
class BarcodeReaderActivity : AppCompatActivity(), ZXingScannerView.ResultHandler {

    private var scannerView: ZXingScannerView? = null
    private lateinit var binding: ActivityBarcodeBinding

    companion object {
        private const val REQUEST_CAMERA = 1

        fun startActivityForResult(activity: Activity, requestCode: Int) {
            val intent = Intent(activity, BarcodeReaderActivity::class.java)
            activity.startActivityForResult(intent, requestCode)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DataBindingUtil.setContentView<ActivityBarcodeBinding>(
            this, R.layout.activity_barcode
        ).apply {
            lifecycleOwner = this@BarcodeReaderActivity
            binding = this
        }
        init()
    }

    private fun init() {
        setToolbar()
        scannerView = binding.scannerView
    }

    private fun setToolbar() {
        binding.toolbar.title = getString(R.string.scan_or_enter_manually)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
        supportActionBar?.run {
            setDisplayShowHomeEnabled(true)
            setHomeButtonEnabled(true)
        }
    }

    public override fun onResume() {
        super.onResume()
        if (UtilityClass.isMarshmallowAndAbove()) {
            if (isPermissionGranted()) {
                startScanning()
            } else {
                requestPermissions(this, arrayOf(CAMERA), REQUEST_CAMERA)
            }
        } else {
            startScanning()
        }
    }

    private fun startScanning() {
        if (scannerView == null) {
            scannerView = ZXingScannerView(this)
            setContentView(scannerView)
        }
        scannerView!!.setResultHandler(this)
        scannerView!!.startCamera()
    }

    private fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            applicationContext, CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    public override fun onDestroy() {
        super.onDestroy()
        scannerView!!.stopCamera()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CAMERA -> if (grantResults.isNotEmpty()) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showToast("Permission Granted, Now you can access camera")
                } else {
                    showToast("Permission Denied, You cannot access and camera")
                    if (UtilityClass.isMarshmallowAndAbove()) {
                        if (shouldShowRequestPermissionRationale(CAMERA)) {
                            showMessageOKCancel(
                                DialogInterface.OnClickListener { _, _ ->
                                    if (UtilityClass.isMarshmallowAndAbove()) {
                                        requestPermissions(
                                            arrayOf(CAMERA), REQUEST_CAMERA
                                        )
                                    }
                                })
                            return
                        }
                    }
                }
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
    }

    private fun showMessageOKCancel(
        okListener: DialogInterface.OnClickListener
    ) {
        AlertDialog.Builder(this@BarcodeReaderActivity)
            .setMessage("You need to allow access to both the permissions")
            .setPositiveButton(Constants.OK, okListener)
            .setNegativeButton(Constants.CANCEL, null)
            .create()
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_barcode_scan, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_done) {
            configureManualBarcode()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun configureManualBarcode() {
        val manualBarcode = binding.manualBarcode.text.toString()
        if (manualBarcode.isNotEmpty()) {
            setResultAndFinish(manualBarcode)
        } else {
            binding.manualBarcode.error = getString(R.string.invalid_barcode)
        }
    }

    override fun handleResult(result: Result) {
        setResultAndFinish(result.text)
    }

    private fun setResultAndFinish(barcode: String) {
        setResult(
            Activity.RESULT_OK, Intent().putExtra(Constants.INTENT_SCANNED_RESULT, barcode)
        )
        finish()
    }
}