package com.diagright.phlebo.ui.controller

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.FragmentAlertDialogBinding
import com.diagright.phlebo.utility.UtilityClass

/**
 * @author by Vinayak Gupta
 */

class AlertDialogFragment : DialogFragment(), View.OnClickListener {

    companion object {
        private const val AMOUNT_TO_COLLECT = "amount_to_collect"
        private const val DISPLAY_PRICE = "display_price"

        @JvmStatic
        fun newInstance(amount: String?, displayPrice: String?): AlertDialogFragment {
            val fragment = AlertDialogFragment()
            val args = Bundle()
            args.putString(AMOUNT_TO_COLLECT, amount)
            args.putString(DISPLAY_PRICE, displayPrice)
            fragment.arguments = args
            return fragment
        }
    }

    private var amount: String = Constants.EMPTY
    private var displayPrice: String = Constants.EMPTY
    private lateinit var binding: FragmentAlertDialogBinding
    private lateinit var callback: AlertDialogCallback

    override fun onAttach(context: Context) {
        super.onAttach(context)
        callback = UtilityClass.getParent(
            this, AlertDialogCallback::class.java
        )
        if (callback == null) {
            throw ClassCastException(
                StringBuilder(context.javaClass.simpleName).append(Constants.MUST_IMPLEMENT).append(
                    AlertDialogFragment::class.java.simpleName
                ).toString()
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.run {
            displayPrice = getString(DISPLAY_PRICE, Constants.EMPTY)
            amount = getString(AMOUNT_TO_COLLECT, Constants.EMPTY)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_alert_dialog, container, false)
        setOnClickListeners()
        return binding.root
    }

    private fun setOnClickListeners() {
        binding.cancel.setOnClickListener(this)
        binding.amountCollected.setOnClickListener(this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.amount.text = displayPrice
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.cancel -> dismiss()
            R.id.amount_collected -> onAmountCollectedClicked()
        }
    }

    private fun onAmountCollectedClicked() {
        if (binding.collectionAmount.text.toString().equals(amount, true)) {
            callback.onAmountCollected()
        } else {
            binding.collectionAmount.error = getString(R.string.amount_not_matched)
        }
    }

    interface AlertDialogCallback {
        fun onAmountCollected()
    }
}