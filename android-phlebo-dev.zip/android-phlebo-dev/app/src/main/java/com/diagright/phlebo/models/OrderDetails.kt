package com.diagright.phlebo.models

import android.os.Parcelable
import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * @author by Vinayak Gupta
 */

@Parcelize
@Keep
data class OrderDetails(
    @SerializedName("patient") val patientInfo: PatientInfo?,
    @SerializedName("test") val testInfo: List<Test>
) : Parcelable