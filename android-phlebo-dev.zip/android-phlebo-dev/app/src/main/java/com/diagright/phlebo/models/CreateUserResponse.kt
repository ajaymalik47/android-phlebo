package com.diagright.phlebo.models

import androidx.annotation.Keep

/**
 * @author by Vinayak Gupta
 */

@Keep
data class CreateUserResponse(
    val mobileNo: String,
    val userExist: Boolean,
    val email: String?,
    val userName: String
)