package com.diagright.phlebo.network.exceptions

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.LayoutAlertDialogBinding
import com.diagright.phlebo.utility.UtilityClass

class ExceptionAlertDialogFragment : DialogFragment(), View.OnClickListener {

    private lateinit var binding: LayoutAlertDialogBinding

    private var message: String? = null

    companion object {
        private const val DIALOG_MESSAGE = "DIALOG_MESSAGE"

        @JvmStatic
        fun newInstance(dialogMessage: String): ExceptionAlertDialogFragment {
            val fragment = ExceptionAlertDialogFragment()
            val args = Bundle()
            args.putString(DIALOG_MESSAGE, dialogMessage)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.layout_alert_dialog, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        extractArguments()
        setMessage()
        binding.positiveBtn.setOnClickListener(this)
    }

    private fun extractArguments() {
        arguments?.let {
            message = it.getString(DIALOG_MESSAGE)
        }
    }

    private fun setMessage() {
        message?.let {
            binding.message.text = UtilityClass.fromHtml(it)
        }
    }

    override fun onClick(v: View?) {
        dismissAllowingStateLoss()
    }

    fun setMessage(message: String) {
        this.message = message
        setMessage()
    }
}