package com.diagright.phlebo.network.model

import androidx.annotation.Keep

@Keep
data class ApiResponseError(val message: String?)