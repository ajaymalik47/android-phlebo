package com.diagright.phlebo.models

import androidx.annotation.Keep

@Keep
/**
 * @param phleboState should be one of these values -> phleboReached or phleboStarted
 */
data class NotifyStateToUserRequest(val orderId: String, val phleboState: String)