package com.diagright.phlebo.utility;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LevelListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.TypefaceSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.text.HtmlCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;

import com.diagright.phlebo.BuildConfig;
import com.diagright.phlebo.PhleboApplication;
import com.diagright.phlebo.Constants;
import com.diagright.phlebo.R;
import com.diagright.phlebo.ui.store.SettingStore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UtilityClass {
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-z]+[a-zA-Z \\-\\.\\']*$");
    private static final int MOBILE_NUMBER_LENGTH = 10;
    private static final int MIN_PASSWORD_LENGTH = 6;
    private static final Pattern EMAIL = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    public static final Pattern NUMERIC = Pattern.compile("\\d+(\\.\\d+)?");
    private static final String FILEPROVIDER = ".fileprovider";
    private static final int MRP_LABEL_LENGTH = 4;
    private static final String LABEL_COUPON_CODE = "Coupon Code";
    private static final String ALGORITHM = "MD5";
    private static DecimalFormat decimalFormat = new DecimalFormat("#.#");
    private static final String REGX_WIDTH_PARAM = "[?w=](\\d+)";
    private static final String DOUBLE_REGEX = "\\.0$";
    private static final String DOUBLE_SLASH_REGEX = "\\.";
    private static final long MILLISECONDS = 1000;

    /**
     * Method returns last path segment based on amp or non amp page,Get last 2nd if amp
     *
     * @param data
     * @return last path segment
     */
    public static String getLastPathSegment(Uri data) {
        List<String> segments = data.getPathSegments();
        String idSegment = segments.get(segments.size() - 1);
        if (idSegment.equals(Constants.AMP)) {
            return segments.get(segments.size() - 2);
        }
        return idSegment;
    }

    public static int getDeviceHeight(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowmanager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowmanager != null) {
            windowmanager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        return displayMetrics.heightPixels;
    }

    public static int getDeviceWidth(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowmanager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowmanager != null) {
            windowmanager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        return displayMetrics.widthPixels;
    }

    public static boolean isEmailValid(String email) {
        if (TextUtility.isEmpty(email)) {
            return false;
        } else {
            return EMAIL.matcher(email).matches();
        }
    }

    public static boolean isNameRegexValid(String value) {
        String nameRegex = "^[a-z_A-Z0-9. ]*$";
        Pattern pattern = Pattern.compile(nameRegex);
        return pattern.matcher(value).matches();
    }

    public static boolean isAddressRegexValid(String value) {
        String addressRegex = "^[a-z_A-Z0-9 [\\\\],'.#/;>`<:&+\"=?()-]*$";
        Pattern addressPattern = Pattern.compile(addressRegex);
        return addressPattern.matcher(value).matches();
    }

    public static boolean isPhoneNumberValid(String contactNumber) {
        if (contactNumber == null || contactNumber.isEmpty()) {
            return false;
        }
        if (contactNumber.trim().length() != MOBILE_NUMBER_LENGTH) {
            return false;
        }
        return NUMERIC.matcher(contactNumber).matches();
    }

    public static boolean isPasswordValid(String password) {
        if (password == null || password.trim().isEmpty()) {
            return false;
        } else {
            return password.trim().length() >= MIN_PASSWORD_LENGTH;
        }
    }

    public static String getStrictVersionName() {
        String versionName = getVersionName();
        if (versionName.contains(Constants.UNDERSCORE)) {
            int indexOfUnderscore = versionName.indexOf(Constants.UNDERSCORE);
            return versionName.substring(0, indexOfUnderscore);
        } else if (versionName.contains(Constants.HYPHEN)) {
            int indexOfHyphen = versionName.indexOf(Constants.HYPHEN);
            return versionName.substring(0, indexOfHyphen);
        } else {
            return versionName;
        }
    }

    private static String getVersionName() {
        String versionName = BuildConfig.VERSION_NAME;
        if (BuildConfig.FLAVOR.equals(Constants.BuildConstants.DEV)) {
            String debugVersionName = SettingStore.getAppVersion();
            if (!TextUtils.isEmpty(debugVersionName)) {
                return debugVersionName;
            } else {
                return versionName;
            }
        } else {
            return versionName;
        }
    }

    public static String getDeviceId() {
        return Settings.Secure.getString(PhleboApplication.getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static int getDeviceOsVersion()
    {
        return Build.VERSION.SDK_INT;
    }

    public static String calculateThumbnailSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        if (wm != null) {
            wm.getDefaultDisplay().getMetrics(displaymetrics);
        }
        int width = displaymetrics.widthPixels;
        if (width <= 360) {
            return "small";
        } else if (width <= 720) {
            return "med";
        } else {
            return "high";
        }
    }

    public static int DPtoPixel(int dp) {
        Resources r = PhleboApplication.getContext().getResources();
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics());
        return px;
    }

    public static String resizeImageUrl(String imageUrl, int widthInPixels) {
        imageUrl = removeWidthQueryParam(imageUrl);
        return String.format("%s?w=%s", imageUrl, widthInPixels);
    }

    private static String removeWidthQueryParam(String url) {
        Pattern p = Pattern.compile(REGX_WIDTH_PARAM);
        Matcher m = p.matcher(url);
        if (m.find()) {
            return m.replaceAll(Constants.EMPTY);
        } else {
            return url;
        }
    }

    public static void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) PhleboApplication.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static Intent createShareIntent(String shareMessage) {
        Intent shareIntent = new Intent();
        shareIntent.setType(Constants.PLAIN_TEXT);
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        return shareIntent;
    }

    public static Intent createShareIntent(String shareMessage, String subject) {
        Intent shareIntent = new Intent();
        shareIntent.setType(Constants.PLAIN_TEXT);
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        return shareIntent;
    }

    public static String getDateUsingFormat(long epochSec, String dateFormatStr) {
        Date date = new Date(epochSec);
        SimpleDateFormat format = new SimpleDateFormat(dateFormatStr,
                Locale.getDefault());
        return format.format(date);
    }

    public static String getDateUsingEpoch(long epoch, String dateFormatString) {
        Date date = new Date(epoch * MILLISECONDS);
        SimpleDateFormat format = new SimpleDateFormat(dateFormatString, Locale.getDefault());
        return format.format(date);
    }

    public static <T> T getParent(@NonNull Fragment fragment, @NonNull Class<T> parentClass) {
        Fragment parentFragment = fragment.getParentFragment();
        if (parentClass.isInstance(parentFragment)) {
            return (T) parentFragment;
        } else if (parentClass.isInstance(fragment.getActivity())) {
            return (T) fragment.getActivity();
        }
        return null;
    }

    public static boolean isLollipopAndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    public static boolean isMarshmallowAndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    public static boolean isAndroid10AndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
    }

    public static boolean isKitkatAndBelow() {
        return Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT;
    }

    public static boolean isKitkatAndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
    }

    public static boolean isNougatAndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1;
    }

    public static boolean isNougat() {
        return Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1;
    }

    public static boolean isAboveNougat() {
        return Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1;
    }

    public static boolean isOreoAndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
    }

    public static boolean isOreoMr1AndAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1;
    }

    public static boolean isBelowOreo() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O;
    }

    public static String getDateTextFromDate(Date date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
        return sdf.format(date);
    }

    public static Date getDateFromDateTxt(String dateTxt, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
        Date date;
        try {
            date = sdf.parse(dateTxt);
            return date;
        } catch (ParseException e) {
            return null;
        }
    }

//    public static boolean isTrueCallerCompatible(Context context, String targetPackage)
//    {
//        List<PackageInfo> packs = context.getPackageManager().getInstalledPackages(0);
//        for (int i = 0; i < packs.size(); i++)
//        {
//            PackageInfo packageInfo = packs.get(i);
//            if (packageInfo.packageName.equals(targetPackage))
//            {
//                int versionCode = packageInfo.versionCode;
//                String versionCodeString = String.valueOf(versionCode);
//                String trueCallerIncompatibleVersion = FirebaseRemoteConfigUtil.getINSTANCE().getTrueCallerIncompatibleVersions();
//                if (!TextUtility.isEmpty(trueCallerIncompatibleVersion))
//                {
//                    String[] trueCallerVersionArray = trueCallerIncompatibleVersion.split(",");
//                    List<String> list = new ArrayList<>(Arrays.asList(trueCallerVersionArray));
//                    for (int j = 0; j < list.size(); j++)
//                    {
//                        String trimmedString = list.get(j).trim();
//                        if (trimmedString.equalsIgnoreCase(versionCodeString))
//                        {
//                            GAUtils.sendEvent(AnalyticsConstants.Categories.TRUECALLER, AnalyticsConstants.Events.TRUECALLER_POP_UP, versionCodeString);
//                            return false;
//                        }
//                    }
//                }
//                return true;
//            }
//        }
//        return true;
//    }

//    public static void sendMail(Context context, String email, String subject, String body)
//    {
//        try
//        {
//            String device = new StringBuilder().append("\n\n\n\n----\n")
//                    .append(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName)
//                    .append(Constants.COMMA_WITH_WHITESPACE)
//                    .append(Build.MODEL).toString();
//            if (body == null)
//            {
//                body = device;
//            } else
//            {
//                body += device;
//            }
//        } catch (PackageManager.NameNotFoundException ignored)
//        {
//            // self package should be present.
//        }
//
//        Intent send = new Intent(Intent.ACTION_SENDTO);
//        String uriText = new StringBuilder().append(Constants.MAILTO)
//                .append(Uri.encode(email))
//                .append(Constants.SUBJECT)
//                .append(Uri.encode(subject))
//                .append(Constants.BODY)
//                .append(Uri.encode(body))
//                .toString();
//        Uri uri = Uri.parse(uriText);
//
//        send.setData(uri);
//        context.startActivity(Intent.createChooser(send, Constants.SEND_MAIL));
//    }

    public static JSONObject bundleToJson(Bundle bundle) {
        JSONObject jsonObject = new JSONObject();
        Set<String> keys = bundle.keySet();
        for (String key : keys) {
            try {
                jsonObject.put(key, bundle.get(key));
            } catch (JSONException ignored) {
                // do nothing
            }
        }

        return jsonObject;
    }

    public static HashMap<String, String> jsonToMap(JSONObject inputJson) throws JSONException {
        Iterator<String> keysItr = inputJson.keys();
        HashMap<String, String> map = new HashMap<>(10);
        while (keysItr.hasNext()) {
            String key = keysItr.next();
            String value = inputJson.getString(key);
            map.put(key, value);
        }
        return map;
    }

    public static boolean isNameValid(String name) {
        if (!TextUtils.isEmpty(name)) {
            return NAME_PATTERN.matcher(name).matches();
        } else {
            return false;
        }
    }

//    public static int getNotificationIcon()
//    {
//        boolean whiteIcon = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP);
//        return whiteIcon ? R.drawable.ic_push_notification : R.mipmap.ic_launcher;
//    }

//    public static void openAppOnPlayStore(Context context)
//    {
//        Intent intent;
//        try
//        {
//            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.MARKET_URI));
//        } catch (ActivityNotFoundException anfe)
//        {
//            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.PLAY_STORE_URL));
//        }
//
//        context.startActivity(intent);
//    }

    public static void showKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) PhleboApplication.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }

    @NonNull
    public static CharSequence fromHtml(@NonNull String source) {
        if (!TextUtility.isEmpty(source)) {
            return HtmlCompat.fromHtml(source, HtmlCompat.FROM_HTML_MODE_LEGACY, null, null);
        }
        return Constants.EMPTY;
    }

    @Nullable
    public static Spanned fromHtml(@Nullable String source, Html.ImageGetter imageGetter) {
        if (!TextUtility.isEmpty(source)) {
            return Html.fromHtml(source, imageGetter, null);
        }
        return null;
    }

    public static void openPdf(Context context, String filePath) {
        File file = new File(filePath);
        Intent target = new Intent(Intent.ACTION_VIEW);
        String authority = new StringBuilder(2).append(context.getApplicationContext().getPackageName()).append(FILEPROVIDER).toString();
        Uri fileUri = FileProvider.getUriForFile(context, authority, file);
        target.setDataAndType(fileUri, Constants.TYPE_PDF);
        target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        target.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        Intent intent = Intent.createChooser(target, context.getString(R.string.open_prescription));
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            // do something
        }
    }

    public static void overrideExitTransition(Activity activity) {
        activity.overridePendingTransition(R.anim.slide_in_from_left, R.anim.slide_out_from_right);
    }

    public static void overrideEnterTransition(Activity activity) {
        activity.overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_from_left);
    }

    public static String getDateFromEpochTime(long timeInSeonds, String formatString) {
        SimpleDateFormat format = new SimpleDateFormat(formatString);
        return format.format(new Date(timeInSeonds * 1000));
    }

    public static boolean isProdBuild() {
        return BuildConfig.FLAVOR.equalsIgnoreCase(Constants.BuildConstants.PROD) && !BuildConfig.DEBUG;
    }

    public static boolean copyText(String copiedText) {
        ClipboardManager clipboardManager = (ClipboardManager) PhleboApplication.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData myClip = ClipData.newPlainText(LABEL_COUPON_CODE, copiedText);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(myClip);
            return true;
        }
        return false;
    }

    public static String getCopiedText() {
        ClipboardManager clipboardManager = (ClipboardManager) PhleboApplication.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clipData;
        if (clipboardManager != null) {
            clipData = clipboardManager.getPrimaryClip();
            if (clipData != null) {
                ClipData.Item item = clipData.getItemAt(0);
                if (item == null || item.getText() == null) return Constants.EMPTY;
                return item.getText().toString();
            }
        }
        return null;
    }

    public static void setRectangleBackground(View view, String backgroundColor, String borderColor) {
        Context context = view.getContext();
        GradientDrawable backgroundDrawable = new GradientDrawable();
        backgroundDrawable.setShape(GradientDrawable.RECTANGLE);
        int eightDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_8dp);
        int fourDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_4dp);
        view.setPadding(eightDp, fourDp, eightDp, fourDp);
        setBackgroundColor(backgroundColor, backgroundDrawable);
        setBackgroundBorder(context, borderColor, backgroundDrawable);
        ViewCompat.setBackground(view, backgroundDrawable);
    }

    public static void setRoundedCornerBackground(View view, String backgroundColor, String borderColor) {
        Context context = view.getContext();
        GradientDrawable backgroundDrawable = new GradientDrawable();
        backgroundDrawable.setShape(GradientDrawable.RECTANGLE);
        int sixteenDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_16dp);
        int eightDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_8dp);
        int fourDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_4dp);
        view.setPadding(eightDp, fourDp, eightDp, fourDp);
        backgroundDrawable.setCornerRadius(sixteenDp);
        setBackgroundColor(backgroundColor, backgroundDrawable);
        setBackgroundBorder(context, borderColor, backgroundDrawable);
        ViewCompat.setBackground(view, backgroundDrawable);
    }

    public static void setSkuStatusBackground(View view, String backgroundColor, String borderColor) {
        Context context = view.getContext();
        GradientDrawable backgroundDrawable = new GradientDrawable();
        backgroundDrawable.setShape(GradientDrawable.RECTANGLE);
        int eightDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_8dp);
        int fourDp = context.getResources().getDimensionPixelSize(R.dimen.dimen_4dp);
        view.setPadding(eightDp, fourDp, eightDp, fourDp);
        backgroundDrawable.setCornerRadius(fourDp);
        backgroundDrawable.setColor(ContextCompat.getColor(view.getContext(), R.color.white));
        setBackgroundColor(backgroundColor, backgroundDrawable);
        setBackgroundBorder(context, borderColor, backgroundDrawable);
        ViewCompat.setBackground(view, backgroundDrawable);
    }

    public static void setBackgroundColor(String backgroundColor, GradientDrawable backgroundDrawable) {
        if (!TextUtils.isEmpty(backgroundColor)) {
            backgroundDrawable.setColor(Color.parseColor(backgroundColor));
        }
    }

    public static void setBackgroundBorder(Context context, String borderColor, GradientDrawable backgroundDrawable) {
        if (!TextUtils.isEmpty(borderColor)) {
            backgroundDrawable.setStroke(context.getResources().getDimensionPixelSize(R.dimen.dimen_1dp), Color.parseColor(borderColor));
        }
    }

    public static String roundToOneDecimalPlaceString(double value) {
        return decimalFormat.format(value);
    }

    public static long getCurrentTimeInMillis() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.SECOND, calendar.getMinimum(Calendar.SECOND));
        calendar.set(Calendar.MILLISECOND, calendar.getMinimum(Calendar.MILLISECOND));
        return calendar.getTimeInMillis();
    }

    public static int generateRandomInt() {
        Random random = new Random();
        int Low = 10;
        int High = 100000;
        return random.nextInt(High - Low) + Low;
    }

    @NonNull
    public static String getUrlWithoutParams(String url) {
        if (url.contains(Constants.QUESTION_MARK)) {
            return url.substring(0, url.indexOf(Constants.QUESTION_MARK));
        } else {
            return url;
        }
    }

    public static Spannable getStrikeThroughMrp(String mrpString) {
        Spannable mrp = new SpannableString(mrpString);
        mrp.setSpan(new StrikethroughSpan(), MRP_LABEL_LENGTH, mrpString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return mrp;
    }

    public static Spannable getFormattedMrp(String mrpString) {
        Context context = PhleboApplication.getContext();
        Spannable mrp = new SpannableString(mrpString);
        mrp.setSpan(new ForegroundColorSpan(ContextCompat.getColor(context, R.color.text_dark_tertiary)), 0, MRP_LABEL_LENGTH, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        mrp.setSpan(new AbsoluteSizeSpan(context.getResources().getDimensionPixelSize(R.dimen.Text_P3)), 0, MRP_LABEL_LENGTH, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        TypefaceSpan typefaceSpan = new TypefaceSpan(context.getString(R.string.sans_serif));
        mrp.setSpan(typefaceSpan, 0, MRP_LABEL_LENGTH, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        return mrp;
    }

    public static boolean isAppInstalled(Context context, String uri) {
        PackageManager pm = context.getApplicationContext().getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    public static String getFormattedDouble(double value) {
        return Double.toString(value).replaceAll(DOUBLE_REGEX, Constants.EMPTY);
    }

    public static Map<String, String> getDeeplinkQueryParams(String deeplinkQueryParams) {
        return new Gson().fromJson(deeplinkQueryParams, new TypeToken<HashMap<String, String>>() {
        }.getType());
    }

    public static byte[] getRequestNonce(String data) {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        byte[] bytes = new byte[24];
        try {
            byteStream.write(bytes);
            byteStream.write(data.getBytes());
        } catch (IOException e) {
            return null;
        }

        return byteStream.toByteArray();
    }

    public static String decodeJws(String jwsResult) {
        if (jwsResult == null) {
            return null;
        }

        final String[] jwtParts = jwsResult.split(DOUBLE_SLASH_REGEX);

        if (jwtParts.length == 3) {
            return new String(Base64.decode(jwtParts[1], Base64.DEFAULT));
        } else {
            return null;
        }
    }

    public static boolean isUriValid(String url) {
        String urlRegex = "^(http|https|diagright|diag-right)://[-a-zA-Z0-9+&@#/%?=~_|,!:.;]*[-a-zA-Z0-9+@#/%=&_|]";
        Pattern urlPattern = Pattern.compile(urlRegex);
        Matcher urlMatcher = urlPattern.matcher(url);
        return urlMatcher.matches();
    }

    public static boolean isDevFlavour() {
        return BuildConfig.FLAVOR.equals(Constants.BuildConstants.DEV);
    }

    public static String normalizeSpace(final String str) {
        final int size = str.length();
        final char[] newChars = new char[size];
        int count = 0;
        int whitespacesCount = 0;
        boolean startWhitespaces = true;
        for (int i = 0; i < size; i++) {
            final char actualChar = str.charAt(i);
            final boolean isWhitespace = Character.isWhitespace(actualChar);
            if (isWhitespace) {
                if (whitespacesCount == 0 && !startWhitespaces) {
                    newChars[count++] = Constants.CHAR_EMPTY;
                }
                whitespacesCount++;
            } else {
                startWhitespaces = false;
                newChars[count++] = (actualChar == 160 ? 32 : actualChar);
                whitespacesCount = 0;
            }
        }
        if (startWhitespaces) {
            return Constants.EMPTY;
        }
        return new String(newChars, 0, count - (whitespacesCount > 0 ? 1 : 0)).trim();
    }

    public static String getMimeType(String filePath) {
        File file = new File(filePath);
        String fileExtension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(file).toString());
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension.toLowerCase());
    }

    public static String generateUUID() {
        return UUID.randomUUID().toString();
    }

    public static String getMD5EncryptedString(String encTarget) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(ALGORITHM);
            messageDigest.update(encTarget.getBytes());
            byte[] messageByteArr = messageDigest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageByteArr) hexString.append(Integer.toHexString(0xFF & b));
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // do nothing
        }
        return Constants.EMPTY;
    }

    public static Map<String, String> getQueryParamsMap(Uri uri) {
        Map<String, String> queryParamMap = null;
        if (uri != null) {
            String query = uri.getQuery();
            String[] pairs;
            if (query != null) {
                pairs = query.split(Constants.AMPERSAND);
                queryParamMap = new HashMap<>(pairs.length);
                for (String pair : pairs) {
                    int index = pair.indexOf(Constants.EQUAL);
                    try {
                        queryParamMap.put(URLDecoder.decode(pair.substring(0, index), Constants.UTF8), URLDecoder.decode(pair.substring(index + 1), Constants.UTF8));
                    } catch (UnsupportedEncodingException e) {
                        // do nothing
                    }
                }
            }
        }
        return queryParamMap;
    }

    public static void prepareBitmapFromHtml(@Nullable String source, LevelListDrawable mDrawable) {
        if (TextUtility.isNotEmpty(source)) {
            try {
                InputStream is = new URL(source).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                if (bitmap != null) {
                    BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmap);
                    mDrawable.addLevel(Constants.BITMAP_LEVEL_LOW, Constants.BITMAP_LEVEL_HIGH, bitmapDrawable);
                    mDrawable.setBounds(0, 0, bitmap.getWidth(), bitmap.getHeight());
                    mDrawable.setLevel(1);
                }
            } catch (IOException e) {
                // do nothing
            }
        }
    }

    public static void logExceptionOnCrashlytics(Throwable throwable) {
//        Crashlytics.logException(throwable);
    }
}