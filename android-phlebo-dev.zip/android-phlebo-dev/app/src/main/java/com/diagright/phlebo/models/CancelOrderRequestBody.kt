package com.diagright.phlebo.models

import androidx.annotation.Keep

@Keep
data class CancelOrderRequestBody(val orderId: String, val patientIds: List<String>, val reason: String)