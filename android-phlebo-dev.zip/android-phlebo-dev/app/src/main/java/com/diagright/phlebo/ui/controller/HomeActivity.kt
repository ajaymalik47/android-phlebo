package com.diagright.phlebo.ui.controller

import ExceptionHandler
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.diagright.phlebo.Constants
import com.diagright.phlebo.R
import com.diagright.phlebo.databinding.ActivityHomeBinding
import com.diagright.phlebo.di.HomeActivityFactory
import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.singletons.LoginSingleton
import com.diagright.phlebo.ui.adapter.OrderListAdapter
import com.diagright.phlebo.ui.states.HomeActivityStates
import com.diagright.phlebo.ui.store.LoginStore
import com.diagright.phlebo.ui.viewmodel.HomeViewModel
import com.diagright.phlebo.utility.openMap
import com.diagright.phlebo.utility.toast.ToastHandler
import kotlinx.android.synthetic.main.app_bar_home.view.*

class HomeActivity : AppCompatActivity(), View.OnClickListener, OrderListAdapter.OrderItemCallback {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var homeViewModel: HomeViewModel

    companion object {
        fun startActivity(context: Context) {
            val intent = Intent(context, HomeActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DataBindingUtil.setContentView<ActivityHomeBinding>(
            this,
            R.layout.activity_home
        ).apply {
            lifecycleOwner = this@HomeActivity
            binding = this
        }
        init()
    }

    private fun init() {
        setupToolbar()
        setOnClickListeners()
        setupViewModel()
    }

    private fun setupToolbar() {
        supportActionBar?.run {
            setDisplayShowHomeEnabled(true)
        }
        setSupportActionBar(binding.homeScreen.toolbar)
        setupNavDrawer(binding.homeScreen.toolbar)
    }

    private fun setupNavDrawer(toolbar: Toolbar) {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
    }

    private fun setupViewModel() {
        val homeActivityFactory = HomeActivityFactory()
        homeViewModel = ViewModelProvider(this, homeActivityFactory).get(HomeViewModel::class.java)
        binding.homeViewModel = homeViewModel
        setObserver()
    }

    private fun setObserver() {
        homeViewModel.getHomeStates().observe(this, Observer {
            when (it) {
                is HomeActivityStates.ShowProgress -> showProgress()
                is HomeActivityStates.HideProgress -> hideProgress()
                is HomeActivityStates.ShowError -> handleError(it.exception)
                is HomeActivityStates.DataLoaded -> onDataLoaded(it.ordersList)
            }
        })
    }

    private fun onDataLoaded(ordersList: List<OrderItem>) {
        hideProgress()
        binding.homeScreen.order_list.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        binding.homeScreen.order_list.adapter = OrderListAdapter(ordersList, this)
        binding.homeScreen.order_list.visibility = View.VISIBLE
    }

    private fun showProgress() {
        binding.homeScreen.progress.visibility = View.VISIBLE
    }

    private fun hideProgress() {
        binding.homeScreen.progress.visibility = View.GONE
    }

    private fun handleError(exception: Exception) {
        hideProgress()
        ExceptionHandler.handle(exception, this)
    }

    private fun setOnClickListeners() {
        val navigationLayout = binding.navView.inflateHeaderView(R.layout.layout_navigation)
        navigationLayout.findViewById<TextView>(R.id.call_to_book).setOnClickListener(this)
        navigationLayout.findViewById<TextView>(R.id.search).setOnClickListener(this)
        navigationLayout.findViewById<TextView>(R.id.legal).setOnClickListener(this)
        navigationLayout.findViewById<TextView>(R.id.logout).setOnClickListener(this)
        setNavigationDetails(navigationLayout)
    }

    private fun setNavigationDetails(navigationLayout: View) {
        navigationLayout.findViewById<TextView>(R.id.email).text =
            String.format(Constants.EMAIL, LoginStore.getEmail())
        navigationLayout.findViewById<TextView>(R.id.mobile).text =
            String.format(Constants.MOBILE, LoginStore.getMobile())
        navigationLayout.findViewById<TextView>(R.id.name).text = LoginStore.getName()
    }

    private fun exitActivity() {
        finish()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.call_to_book -> callToBookClicked()
            R.id.search -> onSearchTestClicked()
            R.id.legal -> onLegalClicked()
            R.id.logout -> logoutUserClicked()
        }
    }

    private fun callToBookClicked() {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(
            String.format(Constants.URI_TELEPHONE, Constants.CUSTOMER_CARE_NUMBER)
        )
        startActivity(intent)
    }

    private fun onSearchTestClicked() {
        showToast(getString(R.string.feature_will_come_soon))
    }

    private fun showToast(message: String) {
        ToastHandler.INSTANCE.showToast(this, message, Toast.LENGTH_SHORT)
    }

    private fun onLegalClicked() {
        WebviewActivity.startActivity(this, Constants.LEGAL_WEB_URL)
    }

    private fun logoutUserClicked() {
        LoginSingleton.isOtpSent = false
        LoginStore.logoutUser()
        finish()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        exitActivity()
    }

    override fun onItemClick(orderItem: OrderItem) {
        OrderDetailsActivity.startActivity(this, orderItem, Constants.REQ_CODE_ORDER_DETAILS)
    }

    override fun onNavigationButtonClicked(orderItem: OrderItem) {
        openMap(orderItem.navigation?.latitude ?: "", orderItem.navigation?.longitude ?: "")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == Constants.REQ_CODE_ORDER_DETAILS) {
                homeViewModel.loadOrderList()
            } else if (requestCode == Constants.REQ_CODE_ACTION_AUTHENTICATION) {
                homeViewModel.loadOrderList()
            }
        }
    }
}
