package com.diagright.phlebo.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.diagright.phlebo.ui.store.LoginStore
import com.diagright.phlebo.ui.store.SettingStore
import com.diagright.phlebo.utility.FcmSyncManager
import com.diagright.phlebo.utility.UtilityClass
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * @author by Vinayak Gupta
 */
class FirebaseMessagingService : FirebaseMessagingService() {

    private val notificationManager: PhleboNotificationManager by lazy { PhleboNotificationManager(applicationContext) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        notificationManager.handleNotification(remoteMessage.data)
    }

    override fun onNewToken(token: String) {
        if (LoginStore.isUserLoggedIn()) {
            FcmSyncManager.syncTokenWithServer(token)
        } else {
            SettingStore.saveFcmToken(token)
        }
    }

    private fun createChannel() {
        if (UtilityClass.isOreoAndAbove()) {
            val important = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = CHANNEL_DESCRIPTION
            }

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(important)
        }
    }

    companion object {
        const val CHANNEL_ID = "important"
        const val CHANNEL_NAME = "Important"
        const val CHANNEL_DESCRIPTION = "Important Notifications"
    }

}