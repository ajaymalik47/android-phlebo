package com.diagright.phlebo.utility;

import androidx.annotation.Nullable;

import java.util.regex.Pattern;

public class TextUtility
{
    private static String[] EMPTY_STRING_ARRAY = new String[]{};

    public static boolean isEmpty(@Nullable CharSequence str)
    {
        return str == null || str.length() == 0;
    }

    public static boolean isNotEmpty(@Nullable CharSequence str)
    {
        return str != null && str.length() > 0;
    }

    public static boolean isNotNullAndTrue(@Nullable Boolean value)
    {
        return value != null && value;
    }

    public static String join(CharSequence delimiter, Iterable tokens)
    {
        StringBuilder sb = new StringBuilder(5);
        boolean isFirstTime = true;
        for (Object token : tokens)
        {
            if (isFirstTime)
            {
                isFirstTime = false;
            } else
            {
                sb.append(delimiter);
            }
            sb.append(token);
        }
        return sb.toString();
    }

    public static String[] split(String text, String expression)
    {
        if (text.length() == 0)
        {
            return EMPTY_STRING_ARRAY;
        } else
        {
            return text.split(expression, -1);
        }
    }

    public static String[] split(String text, Pattern pattern)
    {
        if (text.length() == 0)
        {
            return EMPTY_STRING_ARRAY;
        } else
        {
            return pattern.split(text, -1);
        }
    }

    public static boolean isDigitsOnly(CharSequence inputSequence)
    {
        final int len = inputSequence.length();
        for (int characterAtPoint, i = 0; i < len; i += Character.charCount(characterAtPoint))
        {
            characterAtPoint = Character.codePointAt(inputSequence, i);
            if (!Character.isDigit(characterAtPoint))
            {
                return false;
            } else
            {
                // do nothing
            }
        }
        return true;
    }
}
