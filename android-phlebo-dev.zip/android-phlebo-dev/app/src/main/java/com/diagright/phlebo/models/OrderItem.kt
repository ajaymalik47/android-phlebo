package com.diagright.phlebo.models

import android.os.Parcelable
import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * @author by Vinayak Gupta
 */

@Parcelize
@Keep
data class OrderItem(
    val orderDue: OrderDue?,
    val slot: String?,
    val contact: String?,
    val navigation: RouteNavigation?,
    val orderId: String?,
    val address: String?,
    val userName: String?,
    val email: String?,
    val orderState: String,
    var price: String,
    var displayPrice: String,
    var paymentMode: String,
    var phleboStarted: String? = null,
    var phleboReached: String? = null,
    @SerializedName("testInfo") val orderDetails: List<OrderDetails>
) : Parcelable {

    fun getPatientIds(): List<String> = orderDetails.map { it.patientInfo?.patientId ?: "" }

}