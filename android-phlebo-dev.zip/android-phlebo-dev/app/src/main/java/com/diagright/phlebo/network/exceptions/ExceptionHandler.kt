import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.diagright.phlebo.Constants
import com.diagright.phlebo.network.exceptions.*
import com.diagright.phlebo.ui.store.LoginStore
import com.diagright.phlebo.utility.IntentAction
import com.diagright.phlebo.utility.UtilityClass
import com.diagright.phlebo.utility.toast.ToastHandler
import org.json.JSONException
import java.io.EOFException
import java.io.InterruptedIOException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object ExceptionHandler {
    fun handle(t: Throwable, context: Context?) {
        if (context != null) {
            if (t is UnauthorizedAccessExceptionCustom) {
                logoutUserAndStartLogin(context)
            } else if (t is ServerErrorExceptionCustom) {
                showDialog(Constants.MESSAGE_SERVER_ERROR, context)
            } else if (t is ApiStatusExceptionCustom) {
                showDialog(t.message!!, context)
            }else if (t is CustomHttpException) {
                showDialog(t.message!!, context)
            } else if (t is SocketTimeoutException || t is SocketException || t is InterruptedIOException || t is EOFException) {
                showDialog(Constants.REQUEST_TIMED_OUT, context)
            } else if (t is UnknownHostException) {
                showDialog(Constants.COULDNT_REACH_OUR_SERVERS, context)
            } else if (t is JSONException) {
                if (UtilityClass.isDevFlavour()) {
                    showDialog(Constants.JSON_PARSER_EXCEPTION, context)
                }
            } else if (t is NoNetworkException) {
                showNetworkError(context, t)
            } else {
                if (UtilityClass.isProdBuild()) {
                    UtilityClass.logExceptionOnCrashlytics(t)
                } else {
                    t.localizedMessage?.let { showDialog(it, context) }?: kotlin.run {
                        ToastHandler.INSTANCE.showToast(context, Constants.SOME_ERROR_OCCURRED,Toast.LENGTH_SHORT)
                    }
                }
            }
        }
    }

    private fun logoutUserAndStartLogin(context: Context?) {
        LoginStore.logoutUser()
        val intent = Intent(IntentAction.ACTION_AUTHENTICATION)
        if (context is Activity) {
            context.startActivityForResult(intent, Constants.REQ_CODE_ACTION_AUTHENTICATION)
        } else {
            context!!.startActivity(intent)
        }
        ToastHandler.INSTANCE.showToast(context, Constants.UNAUTHORIZED_ACCESS, Toast.LENGTH_LONG)
    }

    private fun showNetworkError(context: Context?, t: Throwable) {
        try {
            if (context != null) {
                t.message?.let {
                    ToastHandler.INSTANCE.showToast(context, it, Toast.LENGTH_SHORT)
                }
            }
        } catch (ignored: Exception) {
            // ignore if called on worker thread
        }
    }

    private fun showDialog(message: String, context: Context?) {
        if (context != null && context is AppCompatActivity) {
            var fragment: ExceptionAlertDialogFragment? =
                context.supportFragmentManager.findFragmentByTag(ExceptionAlertDialogFragment::class.java.simpleName) as ExceptionAlertDialogFragment?
            if (fragment != null && fragment.isAdded) {
                fragment.setMessage(message)
            } else {
                fragment = ExceptionAlertDialogFragment.newInstance(message)
                val fragmentTransaction = context.supportFragmentManager.beginTransaction()
                fragmentTransaction.add(
                    fragment,
                    ExceptionAlertDialogFragment::class.java.simpleName
                )
                fragmentTransaction.commitAllowingStateLoss()
            }
        }
    }
}