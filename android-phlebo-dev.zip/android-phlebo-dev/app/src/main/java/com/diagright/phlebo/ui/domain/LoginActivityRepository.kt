package com.diagright.phlebo.ui.domain

import com.diagright.phlebo.models.CreateUserResponse
import com.diagright.phlebo.network.model.ApiResponse
import com.diagright.phlebo.network.services.ApiHandler
import com.diagright.phlebo.ui.store.LoginStore
import java.util.HashMap

/**
 * @author by Vinayak Gupta
 */
class LoginActivityRepository {

    suspend fun sendOtp(mobile: String): ApiResponse<CreateUserResponse> {
        val requestBodyParams = HashMap<String, String>(1)
        requestBodyParams["mobileNo"] = mobile
        return ApiHandler.makeLoginRequest().sendOtp(requestBodyParams)
    }

    suspend fun verifyOtp(mobile: String, otp: String): ApiResponse<CreateUserResponse> {
        val requestBodyParams = HashMap<String, String>(2)
        requestBodyParams["mobileNo"] = mobile
        requestBodyParams["otp"] = otp
        return ApiHandler.loginApi.verifyOtp(requestBodyParams)
    }

    fun saveUserDetails(mobileNo: String, email: String?, name: String) {
        LoginStore.saveUserDetails(mobileNo, email, name)
    }
}