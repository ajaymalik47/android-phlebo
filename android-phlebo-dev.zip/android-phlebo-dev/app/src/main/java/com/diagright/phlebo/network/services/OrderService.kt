package com.diagright.phlebo.network.services

import com.diagright.phlebo.models.*
import com.diagright.phlebo.network.model.ApiResponse
import retrofit2.http.*

interface OrderService {

    @GET("of/v1/phlebo/orders")
    suspend fun getOrdersList(): ApiResponse<List<OrderItem>>

    @PUT("of/v1/order/cancel")
    suspend fun cancelOrders(@Body cancelOrderRequestBody: CancelOrderRequestBody): ApiResponse<Any>

    @GET("of/v1/order/cancel-reason")
    suspend fun getCancellationReasons(): ApiResponse<CancelReasonDto>

    @PUT("of/v1/phlebo/order/update")
    suspend fun updateOrder(@Body requestBody: Map<String, String>): ApiResponse<UpdateOrderResponse>

    @PUT("of/v1/phlebo/order/update")
    suspend fun sampleCollected(@Body sampleCollectRequest: SampleCollectRequest): ApiResponse<UpdateOrderResponse>

    @PUT("of/v1/phlebo/order/notify-user")
    suspend fun notifyStateToUser(@Body notifyStateToUserRequest: NotifyStateToUserRequest): ApiResponse<Any>

}