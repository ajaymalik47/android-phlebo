package com.diagright.phlebo.network.exceptions;

public class UnauthorizedAccessExceptionCustom extends CustomHttpException
{
    public UnauthorizedAccessExceptionCustom(String message)
    {
        super(message);
    }
}
