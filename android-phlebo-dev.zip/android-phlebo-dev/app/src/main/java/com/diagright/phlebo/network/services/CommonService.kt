package com.diagright.phlebo.network.services

import com.diagright.phlebo.network.model.ApiResponse
import retrofit2.http.Body
import retrofit2.http.PUT

interface CommonService {

    @PUT("users/v1/device/details")
    suspend fun updateDeviceDetails(
        @Body requestBody: Map<String, String>
    ): ApiResponse<Any>

}