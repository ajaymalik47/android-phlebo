package com.diagright.phlebo.ui.domain

import com.diagright.phlebo.models.OrderItem
import com.diagright.phlebo.network.model.ApiResponse
import com.diagright.phlebo.network.services.ApiHandler

/**
 * @author by Vinayak Gupta
 */
class HomeActivityRepository {

    suspend fun getOrders(): ApiResponse<List<OrderItem>> {
        return ApiHandler.orderApi.getOrdersList()
    }

}